	<?php $__env->startSection('script-local'); ?> 
		<script src="https://cdn.ckeditor.com/4.12.1/full/ckeditor.js"></script>
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('title'); ?> 
		Productos de Innova
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('productos'); ?> active <?php $__env->stopSection(); ?>
	<?php $__env->startSection('contenido'); ?>
		
		<section class="col-12 col-md-10 contenido_principal">
			<header class="encabezado_principal">
				<h1 class="titulo_principal">productos / crear producto</h1>
			</header>
			
			<section class="contenedor_tabla">
				<form class="form_crear_producto" id="form_crear_producto" action="<?php echo e(route('createProducto')); ?>" method="post" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>



					<!-- Información basica del producto -->
					<section class="form-group">
						<h1 class="form-group-titulo">Información básica del producto</h1>
						<div class="form-group-blocks row">

							<!-- Nombre -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="nombre">
									<span class="form_titulos_required">*</span>Nombre del producto
								</label>

								<input autofocus type="text" id="nombre" class="form-control" name="nombre" value="<?php echo e(old('nombre')); ?>" required>

								<?php if($errors->has('nombre')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('nombre')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Precio -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="precio">
									<span class="form_titulos_required">*</span>Precio
								</label>

								<input type="text" id="precio" class="form-control" name="precio" value="<?php echo e(old('precio')); ?>" required>
								<span class="precio-preview">
									<span>COP$ </span><span id="precioPreview"></span>
								</span>

								<?php if($errors->has('precio')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('precio')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Cantidad -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="cantidad">
									<span class="form_titulos_required">*</span>Cantidad
								</label>

								<input type="number" min="1" id="cantidad" class="form-control" name="cantidad" value="<?php echo e(old('cantidad')); ?>" required>

								<?php if($errors->has('cantidad')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('cantidad')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Categoria -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="categoria">
									<span class="form_titulos_required">*</span>Categoria
								</label>

								<select class="form-control" id="categoria" name="categoria" value="<?php echo e(old('categoria')); ?>" required>
									<option>Escoge una categoria</option>
									<?php if(isset($categorias)): ?>
										<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if(old('categorias') == $categoria->id ): ?>
												<option value="<?php echo e($categoria->id); ?>" selected><?php echo e($categoria->categoria_nombre); ?></option>
											<?php else: ?>
												<option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->categoria_nombre); ?></option>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</select>

								<?php if($errors->has('categoria')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('categoria')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Descripción -->
							<div class="form-group-blocks-item col-12">
								<label class="form-group-subtitulo">
									<span class="form_titulos_required">*</span>Descripción del producto
								</label>
								<textarea name="descripcion"><?php echo e(old('descripcion')); ?></textarea>
							</div>
						</div>						
					</section>

					<!-- Detalles del producto -->
					<section class="form-group">
						<h1 class="form-group-titulo">Detalles del producto</h1>
						<div class="form-group-blocks row">

							<!-- Tallas -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="tallas">
									<span class="form_titulos_required"></span>Tallas
								</label>

								<input autofocus type="text" id="tallas" class="form-control" name="tallas" value="<?php echo e(old('tallas')); ?>">

								<?php if($errors->has('tallas')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('tallas')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Colores -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="colores">
									<span class="form_titulos_required"></span>Colores
								</label>

								<input type="text" id="colores" class="form-control" name="colores" value="<?php echo e(old('colores')); ?>">

								<?php if($errors->has('colores')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('colores')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Proveedor -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="proveedor">
									<span class="form_titulos_required"></span>Proveedor
								</label>

				                <select class="form-control" id="proveedor" name="proveedor" value="<?php echo e(old('proveedor')); ?>">
									<option>Escoge un proveedor</option>
									<?php if(isset($proveedores)): ?>
										<?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if(old('proveedor') == $proveedor->id ): ?>
												<option value="<?php echo e($proveedor->id); ?>" selected><?php echo e($proveedor->proveedor_razon_social); ?></option>
											<?php else: ?>
												<option value="<?php echo e($proveedor->id); ?>"><?php echo e($proveedor->proveedor_razon_social); ?></option>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</select>

								<?php if($errors->has('proveedor')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('proveedor')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Marca -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="marca">
									<span class="form_titulos_required"></span>Marca
								</label>

				                <select class="form-control" id="marca" name="marca" value="<?php echo e(old('marca')); ?>">
									<option>Escoge un marca</option>
									<?php if(isset($marcas)): ?>
										<?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if(old('marca') == $marca->id ): ?>
												<option value="<?php echo e($marca->id); ?>" selected><?php echo e($marca->marca_nombre); ?></option>
											<?php else: ?>
												<option value="<?php echo e($marca->id); ?>"><?php echo e($marca->marca_nombre); ?></option>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</select>

								<?php if($errors->has('marca')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('marca')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Etiquetas -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="tags">
									<span class="form_titulos_required">*</span>Etiquetas
								</label> 

								<div class="tags-preview" id="tags-preview"></div>

								<input type="text" id="tagsInput" class="form-control tags-input" name="tags" value="<?php echo e(old('tags')); ?>" required>

								<input type="hidden" id="tags" class="form-control" name="tags" value="<?php echo e(old('tags')); ?>" required>

								<?php if($errors->has('tags')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('tags')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
						</div>						
					</section>

					<!-- Multimedia -->
					<section class="form-group">
						<h1 class="form-group-titulo">Información Multimedia del producto</h1>
						<div class="form-group-blocks row">

							<!-- Imagen de Portada -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="portada">
									<span class="form_titulos_required">*</span>Imagen de portada
								</label>

								<input type="file" class="form-control" id="portada" name="portada" value="<?php echo e(old('portada')); ?>" required>

								<?php if($errors->has('portada')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('portada')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Imagenes complementarias -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="imagenes">
									<span class="form_titulos_required"></span>Imagenes complementarias
								</label>

								<input type="file" class="form-control" name="imagenes[]" multiple>
								
								<?php if($errors->has('imagenes')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('imagenes')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Videos de complementarios -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="videos">
									<span class="form_titulos_required"></span>Videos complementarios <br> <small>Insertar código de YouTube</small>
								</label>

								<textarea rows="5" id="videos" class="form-control" name="videos" placeholder="Separados por comas ( , )"><?php echo e(old('videos')); ?></textarea>

								<?php if($errors->has('videos')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('videos')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>

							<!-- Checkbox descripcion por imagen -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<span class="section_subir_imagenes_checkbox">
									<label class="m-0">¿Descripción por imagen?</label>
									<input opcion="<?php echo e(old('descripcion_por_imagen')); ?>" class="checkbox" type="checkbox" name="descripcion_por_imagen">
								</span>
							</div>
						</div>
					</section>

					<!-- Promociones -->
					<section class="form-group">
						<h1 class="form-group-titulo">Promociones del producto</h1>
						<div class="form-group-blocks row">

							<!-- Promociones -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="promocion">
									<span class="form_titulos_required"></span>Agregar promoción
								</label>
				                <select class="form-control" id="promocion" name="promocion" value="<?php echo e(old('promocion')); ?>">
									<option>Escoge una promoción</option>
									<?php if(isset($promociones)): ?>
										<?php $__currentLoopData = $promociones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promocion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if(old('promocion') == $promocion->id ): ?>
												<option value="<?php echo e($promocion->id); ?>" selected>
													<?php echo e($promocion->promo_nombre . '($texto)'); ?>

													(
														<?php if($promocion->promo_tipo == "%"): ?>
															<?php echo e($promocion->promo_costo . '%'); ?>

														<?php elseif($promocion->promo_tipo == "$"): ?>
															<?php echo e('COP$ '. number_format($promocion->promo_costo, 0, '', '.')); ?>

														<?php else: ?>
															<?php echo e('2x1'); ?>

														<?php endif; ?>
													)
												</option>
											<?php endif; ?>
												<option value="<?php echo e($promocion->id); ?>">
													<?php echo e($promocion->promo_nombre); ?> 
													(
														<?php if($promocion->promo_tipo == "%"): ?>
															<?php echo e($promocion->promo_costo . '%'); ?>

														<?php elseif($promocion->promo_tipo == "$"): ?>
															<?php echo e('COP$ '. number_format($promocion->promo_costo, 0, '', '.')); ?>

														<?php else: ?>
															<?php echo e('2x1'); ?>

														<?php endif; ?>
													)
												</option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</select>
								<?php if($errors->has('promocion')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('promocion')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<?php if($errors->has('producto_promocion')): ?>
			                    <span class="invalid-feedback" role="alert">
			                        <p><?php echo e($errors->first('producto_promocion')); ?></p>
			                    </span>
			                <?php endif; ?>							
						</div>						
					</section>







	                <!-- Nombre -->
					<!-- <div class="form-group">
						<div class="form-group-items">
							<label class="form_titulos" for="producto_nombre"> <span class="form_titulos_required">*</span> Nombre del producto</label>
							<input autofocus type="text" id="producto_nombre" class="form-control" name="producto_nombre" value="<?php echo e(old('producto_nombre')); ?>" required>	
						</div>
		                <?php if($errors->has('producto_nombre')): ?>
		                    <span class="invalid-feedback" role="alert">
		                        <p><?php echo e($errors->first('producto_nombre')); ?></p>
		                    </span>
		                <?php endif; ?>					
					</div> -->					
	                <!-- Descripcion -->
					<!-- <div class="form-group"> -->
						<!-- <div class="form-group-items descripcion_editor">
							<label class="form_titulos" for="producto_descripcion"> <span class="form_titulos_required"></span> Descripción del producto</label> -->
							<!-- <textarea id="producto_descripcion" name="producto_descripcion" placeholder="Escribe la increible descripcion de este producto"></textarea> -->
							<!-- <textarea name="producto_descripcion" placeholder="Escribe la increible descripcion de este producto"><?php echo e(old('producto_descripcion')); ?></textarea>
						</div>
						<?php if($errors->has('producto_descripcion')): ?>
		                    <span class="invalid-feedback" role="alert">
		                        <p><?php echo e($errors->first('producto_descripcion')); ?></p>
		                    </span>
		                <?php endif; ?>
					</div> -->
					<!-- Precio -->
					<!-- <div class="form-group">
						<div class="form-group-items">
							<label class="form_titulos" for="producto_precio"> <span class="form_titulos_required">*</span> Precio del producto</label>
							<input type="number" id="producto_precio" class="form-control" name="producto_precio" placeholder="Sin puntos ni comas, ej: 10000" value="<?php echo e(old('producto_precio')); ?>" required>
			            </div>
						<?php if($errors->has('producto_precio')): ?>
		                    <span class="invalid-feedback" role="alert">
		                        <p><?php echo e($errors->first('producto_precio')); ?></p>
		                    </span>
		                <?php endif; ?>
					</div> -->
					<!-- Cantidad -->
					<!-- <div class="form-group">
						<div class="form-group-items">
							<label class="form_titulos" for="producto_cantidad"> <span class="form_titulos_required">*</span> Cantidades disponibles</label>
							<input type="number" min="1" id="producto_cantidad" class="form-control" name="producto_cantidad" value="<?php echo e(old('producto_cantidad')); ?>" required>
						</div>
						<?php if($errors->has('producto_cantidad')): ?>
		                    <span class="invalid-feedback" role="alert">
		                        <p><?php echo e($errors->first('producto_cantidad')); ?></p>
		                    </span>
		                <?php endif; ?>
					</div> -->
					<!-- Referencia -->
					<!-- <div class="form-group">
						<div class="form-group-items">
							<label class="form_titulos" for="producto_ref"> <span class="form_titulos_required">*</span> Referencia del producto</label>
							<input type="text" id="producto_ref" class="form-control producto_ref" name="producto_ref" placeholder="Este código debe ser unico para cada producto" value="<?php echo e(old('producto_ref')); ?>" required>
						</div>
						<?php if($errors->has('producto_ref')): ?>
		                    <span class="invalid-feedback" role="alert">
		                        <p><?php echo e($errors->first('producto_ref')); ?></p>
		                    </span>
		                <?php endif; ?>
					</div> --> 
					<!-- Categoria -->
					<!-- <div class="form-group">
						<div class="form-group-items">	
							<label class="form_titulos" for="producto_categoria"><span class="form_titulos_required">*</span> Categorias del producto</label>
							<select class="form-control producto_categoria" id="producto_categoria" name="producto_categoria" value="<?php echo e(old('producto_categoria')); ?>" required>
								<option>Escoge una categoria</option>
								<?php if(isset($categorias)): ?>
									<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if(old('producto_categoria') == $categoria->id ): ?>
											<option value="<?php echo e($categoria->id); ?>" selected ><?php echo e($categoria->id); ?> <?php echo e($categoria->categoria_nombre); ?></option>
										<?php else: ?>
											<option value="<?php echo e($categoria->id); ?>" ><?php echo e($categoria->id); ?> <?php echo e($categoria->categoria_nombre); ?></option>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							</select>	
						</div>
						<?php if($errors->has('producto_categoria')): ?>
		                    <span class="invalid-feedback" role="alert">
		                        <p><?php echo e($errors->first('producto_categoria')); ?></p>
		                    </span>
		                <?php endif; ?>
					</div> -->
					<!-- Etiquetas -->
					<!-- <div class="form-group">
						<div class="form-group-items">
							<label class="form_titulos" for="producto_tags"> <span class="form_titulos_required">*</span> Etiquetas del producto</label>
							<input type="text" id="producto_tags" class="form-control" name="producto_tags" placeholder="Separados por comas (zapatos, ropa, celular)" value="<?php echo e(old('producto_tags')); ?>" required>
						</div>
						<?php if($errors->has('producto_tags')): ?>
		                    <span class="invalid-feedback" role="alert">
		                        <p><?php echo e($errors->first('producto_tags')); ?></p>
		                    </span>
		                <?php endif; ?>
					</div> -->
					<!-- Imagen principal -->
					<!-- <div class="form-group">
						<div class="form-group-items">
							<label class="form_titulos" for="Producto_imagen"> <span class="form_titulos_required">*</span> Imagen principal</label>
							<input type="file" class="form-control Producto_imagen" id="producto_imagen" name="producto_imagen" value="<?php echo e(old('producto_imagen')); ?>" >
						</div>
						<?php if($errors->has('producto_imagen')): ?>
		                    <span class="invalid-feedback" role="alert">
		                        <p><?php echo e($errors->first('producto_imagen')); ?></p>
		                    </span>
		                <?php endif; ?>
					</div> -->
					<!-- Promocion -->
					<!-- <div class="form-group">
						<div class="form-group-items">
							<label class="form_titulos" for="producto_promocion">Agregar promoción</label>
							<select class="form-control producto_promocion" id="producto_promocion" name="producto_promocion" value="<?php echo e(old('producto_promocion')); ?>">
								<option value="0">Asigna una promoción al producto </option>
								<?php if(isset($promociones)): ?>
									<?php $__currentLoopData = $promociones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promocione): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if(old('producto_promocion') == $promocione->id ): ?>
											<option value="<?php echo e($promocione->id); ?>" selected><?php echo e($promocione->promo_nombre); ?> ( <?php echo e($promocione->promo_tipo); ?> )  ( <?php echo e($promocione->promo_costo); ?> )</option>
										<?php endif; ?>
											<option value="<?php echo e($promocione->id); ?>"><?php echo e($promocione->promo_nombre); ?> ( <?php echo e($promocione->promo_tipo); ?> )  ( <?php echo e($promocione->promo_costo); ?> )</option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							</select>
						</div>
						<?php if($errors->has('producto_promocion')): ?>
		                    <span class="invalid-feedback" role="alert">
		                        <p><?php echo e($errors->first('producto_promocion')); ?></p>
		                    </span>
		                <?php endif; ?>
					</div> -->
					<!-- Talla -->
					<!-- <div class="form-group">
						<div class="form-group-items">
							<label class="form_titulos" for="producto_tallas">Tamaños ó tallas disponibles</label>
							<input type="text" id="producto_tallas" class="form-control" name="producto_tallas" min="1" placeholder="2cm x 2cm, 28, 30, M, S, L...etc" value="<?php echo e(old('producto_tallas')); ?>">
						</div>
						<?php if($errors->has('producto_tallas')): ?>
		                    <span class="invalid-feedback" role="alert">
		                        <p><?php echo e($errors->first('producto_tallas')); ?></p>
		                    </span>
		                <?php endif; ?>
					</div> -->
					<!-- Colores -->
					<!-- <div class="form-group">
						<div class="form-group-items">
							<label class="form_titulos" for="producto_colores">Colores disponibles</label>
							<input type="text" id="producto_colores" class="form-control" name="producto_colores" placeholder="Separados por comas (verdes, rojos, azul)" value="<?php echo e(old('producto_colores')); ?>">
						</div>
						<?php if($errors->has('producto_colores')): ?>
		                    <span class="invalid-feedback" role="alert">
		                        <p><?php echo e($errors->first('producto_colores')); ?></p>
		                    </span>
		                <?php endif; ?>
					</div> -->

					<!-- imagenes de referencias -->
					<!-- <section class="form-group section_subir_imagenes">
						<h1 class="section_subir_imagenes_titulo">SUBIR IMAGENES COMPLEMENTARIAS <small>(Max 4)</small></h1>
						<input type="file" class="form-control section_subir_imagenes_input" name="producto_imgs_referencia[]" multiple>
 -->
						<!-- <span class="invalid-feedback" role="alert">
		                    <p>Mensaje de error</p>
		                </span> -->

						<!-- <?php if($errors): ?>
							<?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<span class="invalid-feedback" role="alert">
		                    		<p>Mensaje de error</p>
		                		</span>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
		                   <!--  <span class="invalid-feedback" role="alert">
		                        <p><?php echo e($errors->first('producto_imgs_referencia.0')); ?></p>
		                    </span> -->
		                <!-- <?php endif; ?> -->
		               <!--  <?php if($errors->has('producto_imgs_referencia')): ?>
		                    <span class="invalid-feedback" role="alert">
		                        <p><?php echo e($errors->first('producto_imgs_referencia')); ?></p>
		                    </span>
		                <?php endif; ?> -->
						<!-- <h1 class="section_subir_imagenes_titulo mt-4">SUBIR VIDEOS COMPLEMENTARIAS</h1>
						<input type="text" class="form-control section_subir_imagenes_input" name="producto_videos_referencia" placeholder="Separe cada código de video con una coma ( , )">

						<?php if($errors->has('producto_videos_referencia')): ?>
		                    <span class="invalid-feedback" role="alert">
		                        <p><?php echo e($errors->first('producto_videos_referencia')); ?></p>
		                    </span>
		                <?php endif; ?>
						<span class="section_subir_imagenes_checkbox">
							<p>¿Imagenes de descripción?</p>
							<input opcion="<?php echo e(old('producto_tieneImgDescripcion')); ?>" type="checkbox" name="producto_tieneImgDescripcion">						
						</span>
					</section> -->

					<!-- Barra de aceptar registro o cancelar registro -->

					<div class="form_botones_accion">
						<button type="reset" class="boton-defaul-rojo"> Cancelar </button>
						<button type="submit" class="boton-defaul-azul" id="btn-crear-producto"> Guardar </button>
					</div>
				</form>
			</section>
		</section>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>