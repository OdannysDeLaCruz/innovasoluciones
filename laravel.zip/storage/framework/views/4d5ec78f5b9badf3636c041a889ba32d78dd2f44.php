<section class="contenedor_perfil">
	<section class="perfil row">
		<nav class="col-xs-12 col-sm-3 perfil_menu">
			<ul class="perfil_menu_ul">
				<li><a class="<?php echo $__env->yieldContent('perfil'); ?>" href="<?php echo e(route('perfil')); ?>">Perfil</a></li>
				<li><a class="<?php echo $__env->yieldContent('pedidos'); ?>" href="<?php echo e(route('pedidos')); ?>">Pedidos</a></li>
				<!-- <li><a class="<?php echo $__env->yieldContent('compras'); ?>" href="<?php echo e(route('compras')); ?>">Compras</a></li> -->
				<li><a class="<?php echo $__env->yieldContent('facturas'); ?>" href="<?php echo e(route('facturas')); ?>">Facturas</a></li>
			</ul>
		</nav>
		<?php echo $__env->yieldContent('content'); ?>
	</section>		
</section>

<!-- SECCION FOOTER -->
<?php echo $__env->make('includes/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- FIN FOOTER -->

<!-- SECCION SCRIPTS JS -->
<?php echo $__env->make('includes/scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- FIN SCRIPTS JS -->