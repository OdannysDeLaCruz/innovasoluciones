<?php if(isset($response)): ?>
	<?php echo e($response); ?>

<?php else: ?> 
	<?php echo e('Ha ocurrido un error'); ?>

<?php endif; ?>