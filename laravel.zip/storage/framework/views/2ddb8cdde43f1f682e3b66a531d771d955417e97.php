<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/media-query.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<title> Compras realizadas | Usuario </title>
</head>
<body>

	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->
	
	<!-- SECCION PERFIL -->
	
		<?php $__env->startSection('pedidos'); ?> active <?php $__env->stopSection(); ?>
		<?php $__env->startSection('content'); ?>
			<section class="col-xs-12 col-sm-9 pl-sm-2 compras">
				<h1 class="compras_titulo mt-5 mt-sm-0">
					Pedido N° <?php echo e($idPedido); ?>, 
					<span class="compras_titulo_total">
						<?php if(isset($total_pedido)): ?>
							Valor del pedido: $ <?php echo e($total_pedido); ?>

						<?php endif; ?>
					</span>
				</h1>
		
				<?php if(isset($detalle_pedidos)): ?>
					<?php $__currentLoopData = $detalle_pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="compras_pedido">
							<label class="compras_pedido_info">
								<a target="_blanc" href="/productos/<?php echo e($detalle['id_producto']); ?>-<?php echo e($detalle['descripcion']); ?>">
									<img class="compras_pedido_info_img" src="<?php echo e($detalle['imagen']); ?>"></img>
								
								</a>
								<div class="compras_pedido_info_datos">
									<a target="_blanc" href="/productos/<?php echo e($detalle['id_producto']); ?>-<?php echo e($detalle['descripcion']); ?>">
										<label class="compras_pedido_info_nombre"><?php echo e($detalle['descripcion']); ?></label>
									</a>
									<label class="compras_pedido_info_monto">
										$ <?php echo e(number_format($detalle['precio'], 2)); ?> x <?php echo e($detalle['cantidad']); ?> unidad(es), 
										<b>-<?php echo e($detalle['descuento_porcentual']); ?>%</b></label>

									<label class="compras_pedido_info_monto">
										<?php 
											$precio = $detalle['precio'] * $detalle['cantidad'];
											$a_descontar = $precio * ($detalle['descuento_porcentual'] / 100);
											$total = $precio - $a_descontar;
										?> 
										Total: $ <?php echo e(number_format($total, 2)); ?> 
									</label>	
								</div>
							</label>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
				<!-- si no existe compra, es por que la idPedido no existe para este usuario, verificamos si existe la variable Error -->
				<?php if(isset($Error)): ?>
					<div class="compras_pedido">
						<label class="compras_pedido_error"><?php echo e($Error); ?></label>
					</div>
				<?php endif; ?>
			</section> 
		<?php $__env->stopSection(); ?>
	<!-- FIN PERFIL -->
</body>
</html>
<?php echo $__env->make('users/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>