<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	
	<!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>" > -->

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/media-query.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<title> Productos | Innova Soluciones</title>
</head>
<body>
	
	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->

	<!-- SECCION CATEGORIAS -->
	<?php echo $__env->make('includes/menu_categorias', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<!-- FIN CATEGORIAS -->
	
	<!-- SECCION PRODUCTOS -->
	<section class="seccion_productos">
		<span class="seccion_productos_logo">
			<div class="contenedor_logo">
				<img class="logo" src="<?php echo e(asset('img/logos/LogoInnovate.svg')); ?>">
			</div>
		</span>
		<span>
			<?php if(isset($search)): ?> 
				<?php if(isset($productos)): ?>
					<h1 style="font-size: 18px; text-align: center;">
						<?php echo e(count($productos)); ?> resultados para <b><?php echo e($search); ?></b>
					</h1>
				<?php endif; ?>
			<?php endif; ?>
			
		</span>
		<div class="seccion_productos_content">
			<?php if(isset($productos)): ?>
				<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php 
						$ref  = $producto['producto_ref'];
						$desc = str_replace(" ", "-", $producto['producto_descripcion']);
					?>
					<section class="producto">
						<figure>
							<a href="/productos/<?php echo e($ref); ?>-<?php echo e($desc); ?>">
								<!-- <img src="<?php echo e($producto['producto_imagen']); ?>" class="producto_img" alt="<?php echo e($producto['producto_descripcion']); ?>"> -->
								<img src="<?php echo e(asset('img/zapatos.jpg')); ?>" class="producto_img">							
							</a>
						</figure>
						<div class="producto_info">
							<a href="/productos/<?php echo e($ref); ?>-<?php echo e($desc); ?>">
								<h1 class="producto_titulo"> <?php echo e($producto['producto_descripcion']); ?></h1>
							</a>

							<?php if($producto['promo_tipo'] == 'descuento%'): ?>
								<span class="producto_precio_anterior">
									<p class="descuento">
										-<?php echo e($producto['promo_costo']); ?>%
									</p>
									<p class="precio_anterior"> $<?php echo e(number_format($producto['producto_precio'], 0, ',', '.')); ?> </p>
								</span>

							<?php elseif($producto['promo_tipo'] == 'peso'): ?>
								<span class="producto_precio_anterior">
									<p class="descuento">
										-$<?php echo e(number_format($producto['promo_costo'], 0, ',', '.')); ?>							
									</p>
									<p class="precio_anterior"> $<?php echo e(number_format($producto['producto_precio'], 0, ',', '.')); ?> </p>
								</span>
							<?php elseif($producto['promo_tipo'] == '2x1'): ?>
								<span class="producto_precio_anterior">
									<p class="descuento">
										<?php echo e($producto['promo_tipo']); ?>					
									</p>
								</span>
							<?php endif; ?>
						</div>

						<label class="producto_precio">

								<?php
								if($producto['promo_tipo'] == 'descuento%') {
									$descuento = $producto['producto_precio'] * ($producto['promo_costo'] / 100);
									$total = $producto['producto_precio'] - $descuento;
								}
								elseif($producto['promo_tipo'] == 'peso'){
									$total = $producto['producto_precio'] - $producto['promo_costo'];
								}
								else {
									$total = $producto['producto_precio'];
								}
								?>
								<p>$<?php echo e(number_format($total, 0, ',', '.')); ?> </p>		
						</label>
						
					</section>	
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<?php else: ?> 
			<div class="respuesta">
				<img src="<?php echo e(asset('img/logos/svg/box.svg')); ?>">
				<p>
					<?php if(isset($response)): ?>
						<?php echo e($response); ?> 
							<?php if(isset($search)): ?> <b>  <?php echo e($search); ?> </b> <?php endif; ?><br>
							Ver otras categorias de <a href="/productos">productos</a>
					<?php endif; ?>
				</p>
			</div>
		<?php endif; ?>
	</section>
	<!-- FIN SECCION PRODUCTOS -->
	
	<!-- SECCION FOOTER -->
	<?php echo $__env->make('includes/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<!-- FIN FOOTER -->
	
	<!-- SECCION SCRIPTS JS -->
	<?php echo $__env->make('includes/scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN SCRIPTS JS -->

</body>
</html>
