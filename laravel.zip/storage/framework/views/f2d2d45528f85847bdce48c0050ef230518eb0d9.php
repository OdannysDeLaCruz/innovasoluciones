<div class="header">
	<div class="header-logotipo">
		<img src="<?php echo e(asset('img/logos/logo-innova-negro.svg')); ?>">		
	</div>
	<div class="header-info">
		<h1>Innova Inc</h1>
		<p>Cll 6b # La Castellana Valledupar, Colombia</p><br>
		<p>https://www.innovainc.co | team@innovainc.co +57 3023097029</p>
	</div>
</div>