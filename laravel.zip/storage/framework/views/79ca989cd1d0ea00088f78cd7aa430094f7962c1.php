<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>" >

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/media-query.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<title>Referencias y descripción del producto | Home </title>
</head>
<body>
	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->
	
	<section class="contenido_principal">
		<section class="section_principal">
			<span class="section_principal_titulo"> 
				<a href=""> < </a>
				<h1> <?php echo e($producto['descripcion']); ?> </h1>
			</span>
			<a href="<?php echo e(route('showDetallesCompra', [ $producto['ref'], $producto['descripcion-url'] ])); ?>">
				<button class="section_principal_btncomprar">Información de compra</button>				
			</a>
		</section>
		<section class="section_referencias">
			<!-- <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<img class="section_referencias_img" src="<?php echo e(asset($imagen['nombre_imagen'])); ?>" alt="<?php echo e($imagen['nombre_imagen']); ?>">
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
	        <img class="section_referencias_img" src="<?php echo e(asset('img/productos/bici/1.jpg')); ?>">
	        <img class="section_referencias_img" src="<?php echo e(asset('img/productos/bici/2.jpg')); ?>">
	        <img class="section_referencias_img" src="<?php echo e(asset('img/productos/bici/3.jpg')); ?>">
	        <img class="section_referencias_img" src="<?php echo e(asset('img/productos/bici/4.jpg')); ?>">
	        <img class="section_referencias_img" src="<?php echo e(asset('img/productos/bici/5.jpg')); ?>">
	        <img class="section_referencias_img" src="<?php echo e(asset('img/productos/bici/6.jpg')); ?>">
	        <img class="section_referencias_img" src="<?php echo e(asset('img/productos/bici/7.jpg')); ?>">
	        <img class="section_referencias_img" src="<?php echo e(asset('img/productos/bici/8.jpg')); ?>">
	        <img class="section_referencias_img" src="<?php echo e(asset('img/productos/bici/9.jpg')); ?>">
	        <img class="section_referencias_img" src="<?php echo e(asset('img/productos/bici/10.jpg')); ?>">
	        <img class="section_referencias_img" src="<?php echo e(asset('img/productos/bici/11.jpg')); ?>">
		</section>
	</section>

	<!-- SECCION FOOTER -->
	<?php echo $__env->make('includes/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<!-- FIN FOOTER -->
	
	<!-- SECCION SCRIPTS JS -->
	<?php echo $__env->make('includes/scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN SCRIPTS JS -->
	
</body>
</html>