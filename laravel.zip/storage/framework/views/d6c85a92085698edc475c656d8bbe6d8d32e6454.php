
<!DOCTYPE html>
<html lang="es">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta charset="UTF-8">
	<title>FACTURA_<?php echo e($pedido[0]['ref_venta']); ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/factura.css')); ?>">

</head>
<body>
	<div class="header">
		<div class="header-logotipo">
			<img src="<?php echo e(asset('img/logos/logo-innova-negro.png')); ?>">		
		</div>
		<div class="header-info">
			<p>Mz 15 Casa 6b La Castellana, Valledupar, Colombia</p>
			<p>https://www.innovainc.co | team@innovainc.co | +57 3023097029</p>
		</div>
	</div>

	<div style="margin: 30px 0px;">
		<h2 style="margin: 0px; font-size: 24px; color: #00313a;">FACTURA</h2>
		<p style="margin: 0 0 10px; font-size: 13px; color: #00313a;">REF: <?php echo e($pedido[0]['ref_venta']); ?></p>
	</div>

	<div class="detalle-factura">
		<div class="bloque bloque-izquierdo">
			<ul class="bloque-items">
				<li class="bloque-item-titulo">
					<div>
						Fecha de emisión: <br>
						<p><?php echo strftime('%d de %B de %Y', strtotime($pedido[0]['fecha_creado'])); ?></p>
					</div>
				</li>
				<li class="bloque-item-titulo">
					<div>
						Fecha limite: <br> 
						<p>24/08/2019</p>
					</div>									
				</li>
				<li class="bloque-item-titulo">
					<div>
						Facturar a: <br>
						<p style="line-height: 20px;"><?php echo e(Auth::user()->usuario_nombre . ' ' . Auth::user()->usuario_apellido); ?> <br> CC. <?php echo e(Auth::user()->usuario_cedula); ?></p>
					</div>
				</li>
			</ul>
		</div>
		<div class="bloque bloque-derecho">
			<ul class="bloque-items">				
				<li class="bloque-item-titulo">
					<div>
						Enviar a: <br>
						<p style="line-height: 20px;">
							<?php echo e($direccion[0]['nombre_completo']); ?> <br>
						</p> 
					</div>
				</li>
				<li class="bloque-item-titulo">
					<div>
						Dirección: <br>
						<p style="line-height: 20px;">
							<?php echo e($direccion[0]['direccion']); ?> <br>
							<?php echo e($direccion[0]['ciudad']); ?>, <?php echo e($direccion[0]['estado']); ?>, <?php echo e($direccion[0]['codigo_postal']); ?>, <?php echo e($direccion[0]['pais']); ?>

						</p> 
					</div>					
				</li>
			</ul>
		</div>
	</div>
	<!-- TABLA DE RESUMEN DE PEDIDO -->
	<div class="contenedor-tabla-productos">
		<table class="productos">
			<thead>
				<tr>
					<th style="text-align: left; width: 300px;">Producto</th>
					<th style="text-align: right; width: 100px;">Precio (COP$)</th>
					<th style="text-align: right; width: 40px;">Cant</th>
					<th style="text-align: right; width: 100px;">DCTO</th>
					<th style="text-align: right; width: 100px;">Total (COP$)</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td style="text-align: left;"><?php echo e($detalle['detalle_nombre']); ?></td>
						<td style="text-align: right;"> <?php echo e(number_format($detalle['detalle_precio'], 0, '', '.')); ?> </td>
						<td style="text-align: right;"> <?php echo e($detalle['detalle_cantidad']); ?> </td>
						<td style="text-align: right;"> 
							<?php if($detalle['detalle_promo_tipo'] == '%'): ?>
					 			-<?php echo e($detalle['detalle_promo_costo']); ?>%
					 		<?php elseif($detalle['detalle_promo_tipo'] == '$'): ?>
					 			- <?php echo e(number_format($detalle['detalle_promo_costo'], 0, '', '.')); ?>

					 		<?php elseif($detalle['detalle_promo_tipo'] == '2x1'): ?>
					 			<?php echo e('2x1'); ?>

					 		<?php endif; ?>
						</td>
						<td style="text-align: right;" class="total"><?php echo e(number_format($detalle['detalle_precio_final'], 0, '', '.')); ?></td>
					</tr>					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>

	<!-- TABLA DE TOTAL -->
	<div class="contenedor-tabla-total">
		<table>
			<tr>
				<th class="titulos">Subtotal</th>
			    <td class="texto" style="font-weight: bold;"> COP$ <?php echo e(number_format($subtotal, 0, '', '.')); ?> </td>
			</tr>
			<tr>
			 	<th class="titulos">Descuento por código</th>
			 	<td class="texto"> 
			 		<?php if($pedido[0]['promo_tipo'] == '%'): ?>
			 			-<?php echo e($costo_promo_pedido); ?>%
			 		<?php elseif($pedido[0]['promo_tipo'] == '$'): ?>
			 			COP$ <?php echo e(number_format($costo_promo_pedido, 0, '', '.')); ?>

			 		<?php endif; ?>
			 	</td>
			</tr>
			<tr>
			 	<th class="titulos">Costo de envío</th>
			 	<td class="texto"> Envio Gratís </td>
			</tr>
			<tr>
				<th class="titulos">IVA incluido</th>
				<td class="texto">19%</td>
			</tr>
			<tr class="total">
				<th class="titulos" style="color: #fff">TOTAL A PAGAR</th>
				<td class="texto" style="font-size: 17px; color: #fff; font-weight: bold;">
					COP$ <?php echo e(number_format($total, 0, '', '.')); ?>

				</td>
			</tr>
		</table>
	</div>

</body>
</html>