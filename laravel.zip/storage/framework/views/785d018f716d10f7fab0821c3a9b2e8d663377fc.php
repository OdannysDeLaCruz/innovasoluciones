<section class="seccion_algunos_productos">
	<h1 class="seccion_algunos_productos_titulo">Estos son algunos de nuestros productos</h1>
	<div class="seccion_algunos_productos_content">

		<?php $__currentLoopData = $algunos_productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $algunos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php 
				$ref  = $algunos['producto_ref'];
				$desc = str_replace(" ", "-", $algunos['producto_descripcion']);
			?>
			<section class="producto">
				<figure>
					<a href="/productos/<?php echo e($ref); ?>-<?php echo e($desc); ?>">
						<!-- <img src="<?php echo e($algunos['imagen']); ?>" class="producto_img" alt="<?php echo e($algunos['descripcion']); ?>"> -->
						<!-- <img src="img/zapatos.jpg" class="producto_img"> -->
						<img src="<?php echo e($algunos['producto_imagen']); ?>" class="producto_img">
					</a>
				</figure>
				<!-- <div class="producto_info">
					<a href="/productos/<?php echo e($ref); ?>-<?php echo e($desc); ?>">
						<h1 class="producto_titulo"> <?php echo e($algunos['descripcion']); ?></h1>
					</a>
					<?php if($algunos['descuento'] != 0): ?>
						<span class="producto_precio_anterior">
							<p class="precio_anterior"> $<?php echo e(number_format($algunos['precio'], 2)); ?> </p>
							<p class="descuento">
							-<?php echo e($algunos['descuento']); ?>%
							</p>
						</span>
					<?php endif; ?>

					<label class="producto_precio">
						<?php 
							$descuento = $algunos['precio'] * ($algunos['descuento'] / 100);
							$total = $algunos['precio'] - $descuento;
						?>
						<p>$<?php echo e(number_format($total, 2)); ?> <small>COP</small></p>
					</label>					
				</div> -->
			</section>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>
	<div class="btn_seccion_ver_mas botones_innova">
		<a href="/productos">Ver mas productos</a>
	</div>
</section>