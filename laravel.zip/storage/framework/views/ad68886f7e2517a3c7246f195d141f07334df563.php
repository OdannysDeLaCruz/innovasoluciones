	<?php $__env->startSection('title'); ?> 
		Pedidos de los clientes
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('pedidos'); ?> active <?php $__env->stopSection(); ?>
	<?php $__env->startSection('contenido'); ?>
		<section class="col-10 col-sm-10 col-md-10 contenido_principal">
			<header class="encabezado_principal">
				<h1 class="titulo_principal">pedidos</h1>
			</header>
			<!-- TABLA DE PEDIDOS -->
			<section class="filtro">
				<form class="form-inline filtro_form" action="" method="POST">

					<input type="number" name="id_pedido" class="form-control filtro_id" placeholder="Id">
					<input type="text" name="direccion_pedido" class="form-control filtro_direccion" placeholder="Dirección">
					<input type="text" name="cliente_pedido" class="form-control filtro_cliente" placeholder="Cliente">
					
					<select name="modo_pago_pedido" class="form-control filtro_modo_pago">
						<option>Modo de pago</option>
						<option value="">Payu</option>
						<option value="">Efecty</option>
						<option value="">Transferencia Bancaria</option>
					</select>
					<select name="estado_pedido" class="form-control filtro_estado">
						<option>Estado</option>
						<option value="1">Pago</option>
						<option value="0">Pendiente</option>
					</select>
					<input type="text" name="codigo_descuento_pedido" class="form-control filtro_codigo" placeholder="Código de descuento">
					<div class="input-group">
						<div class="input-group-prepend">
					    	<div class="input-group-text">$</div>
					    </div>
					    <input type="number" min="1" name="total_pedido" class="form-control filtro_total" placeholder="Total">
					</div>
					<input type="date" name="fecha_pedido" class="form-control filtro_fecha">
					<button type="submit" class="filtro_btn_filtrar">
						<i class="fa fa-search"></i>
						Buscar
					</button>
				</form>
			</section>
			<section class="contenedor_tabla">
				<table class="table table-hover table-bordered tables_admin">
					<thead>
						<tr>
							<th class="table_id">ID</th>
							<th class="table_direccion">Dirección</th>
							<th class="table_direccion">Modo de entrega</th>
							<th class="table_cliente">Cliente</th>
							<th class="table_modo_pago">Pago</th>
							<th class="table_estado">Estado</th>
							<th class="table_codigo">Código desc</th>
							<th class="table_total">Total</th>
							<th class="table_fecha">Fecha</th>
							<th class="table_opcion"></th>
						</tr>
					</thead>
					<tbody>
						<?php if(isset($pedidos)): ?>
							<?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr class="tables_admin_fila">
								<td><?php echo e($pedido['id']); ?></td>								
								<td class="pedido_direccion">
									<?php echo e($pedido['direccion']); ?>

								</td>
								<td>
									<?php echo e($pedido['entrega']); ?>

								</td>
								<td><?php echo e($pedido['cliente']); ?></td>
								<td><?php echo e($pedido['modo_pago']); ?></td>
								<td>
									<?php if($pedido['estado'] == 'aprobado'): ?>
										<div class="pedido_estado exitoso">
											Pago exitoso
										</div>
									<?php else: ?>
										<div class="pedido_estado rechazado">
											Pago rechazado
										</div>
									<?php endif; ?>
								</td>
								<td><?php echo e($pedido['codigo']); ?></td>
								<td>$<?php echo e(number_format( $pedido['total'], 2 )); ?> </td>
								<td><?php echo e($pedido['fecha']); ?></td>
								<td class="menu_opcion">
									<i class="fa fa-ellipsis-h menu_opcion_logo" id="menu_opcion_logo_<?php echo e($pedido['id']); ?>" aria-hidden="true"></i>
									<div class="menu_opcion_items">
										<a href="">Editar</a>
										<a href="">Eliminar</a>
									</div>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
						<?php endif; ?>
					</tbody>
				</table>
				<?php if($misPedidos->links()): ?>
					<section class="paginacion_links">
						<p class="text-muted">Página <?php echo e($misPedidos->currentPage()); ?> de <?php echo e($misPedidos->total()); ?> resultados</p>
						<?php echo e($misPedidos->links()); ?>

					</section>
				<?php endif; ?>
			</section>
		</section>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>