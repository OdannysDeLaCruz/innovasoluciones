<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/media-query.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<title> Productos | Innova Soluciones</title>
</head>
<body>
	
	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->

	<!-- SECCION PRINCIPAL -->
	<section class="contenedor_payment row">
		<div class="col-md-8 seccion_metodo_pago">
			<h1 class="payment_titulos">¡Casi terminas!, utilizamos Payu para brindarte diferentes formas de pago</h1>
			<ul class="payment_proceso_tarjeta seccion_metodo_pago_lista">
				<li><span class="fa fa-credit-card-alt fa-lg"></span> Tarjeta de crédito</li>
				<li><span class="fa fa-exchange fa-lg"></span> Debito bancario PSE</li>
				<li><span class="fa fa-money fa-lg"></span> Pago en efectivo</li>
				<li><span class="fa fa-university fa-lg"></span> Pago en bancos</li>
			</ul>
			<!-- Formulario de pago de PAYU -->
			<div id="formulario_payu" class="contenedor_formulario_payu payment_datos_botones">
				<form method="post" id="enviar-formulario-payu" action="https://sandbox.checkout.payulatam.com/ppp-web-gateway-payu/">

					<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

				  	<input name="merchantId"    type="hidden"  value="<?php echo e($dataPayu['merchantId']); ?>">
				  	<input name="accountId"     type="hidden"  value="<?php echo e($dataPayu['accountId']); ?>" >
				  	<input name="description"   type="hidden"  value="<?php echo e($dataPayu['description']); ?>">
				  	<input name="extra2" id="pedido_id" type="hidden"  value="<?php echo e($dataPayu['extra2']); ?>">
				  	<input name="referenceCode" type="hidden"  value="<?php echo e($dataPayu['referenceCode']); ?>" >
				  	<input name="amount"        type="hidden"  value="<?php echo e($dataPayu['amount']); ?>"   >
				  	<input name="tax"           type="hidden"  value="<?php echo e($dataPayu['tax']); ?>"  >
				  	<input name="taxReturnBase" type="hidden"  value="<?php echo e($dataPayu['taxReturnBase']); ?>" >
				  	<input name="currency"      type="hidden"  value="<?php echo e($dataPayu['currency']); ?>" >
				  	<input name="signature"     type="hidden"  value="<?php echo e($dataPayu['signature']); ?>"  >
				  	<input name="test"          type="hidden"  value="<?php echo e($dataPayu['test']); ?>" >
				  	
				  	<input name="buyerFullName" type="hidden"  value="<?php echo e($dataPayu['buyerFullName']); ?>" >
				  	<input name="buyerEmail"    type="hidden"  value="<?php echo e($dataPayu['buyerEmail']); ?>" >
				  	<input name="telephone"    type="hidden"  value="<?php echo e($dataPayu['telephone']); ?>" >
				  	
				  	<input name="shippingAddress" type="hidden"  value="<?php echo e($dataPayu['shippingAddress']); ?>" >
				  	<input name="shippingCity"  type="hidden"  value="<?php echo e($dataPayu['shippingCity']); ?>" >
				  	<input name="shippingCountry" type="hidden"  value="<?php echo e($dataPayu['shippingCountry']); ?>" >
				  	
				  	<input name="responseUrl"   type="hidden"  value="<?php echo e($dataPayu['responseUrl']); ?>" >
				  	<input name="confirmationUrl" type="hidden"  value="<?php echo e($dataPayu['confirmationUrl']); ?>" >

					<section class="payment_proceso_tarjeta tarjeta_form_btn_payu">
						<!-- Este botón envia los datos a payu, pero antes elimina el carrito de compra desde app.js -->
						<button type="submit" class="btn_datos_envio" id="crearPedido">
							Pagar con 
							<img class="logo_payu" src="<?php echo e(asset('img/logos/payu.png')); ?>">
						</button>
					</section>
				</form>
			</div>
		</div>	
		<div class="col-md-4 seccion_resumen_pedido">
			<section class="payment_proceso_tarjeta tarjeta_resumen_pedido">
				<span class="payment_proceso_tarjeta titulo_resumen_table">
					<strong>Resumen de la pedido</strong>
				</span>
				<table class="table table-bordered resumen_table">
				  	<tr>
				    	<th style="font-weight: 400;">TOTAL A PAGAR</th>
				    	<td>$<?php echo e(number_format($total_pagar, 0, ',', '.')); ?></td>
				  	</tr>
				</table>
			</section>
		</div>
	</section>
	<!-- FIN PRINCIPAL -->

	<!-- SECCION FOOTER -->
	<?php echo $__env->make('includes/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<!-- FIN FOOTER -->
	
	<!-- SECCION SCRIPTS JS -->
	<?php echo $__env->make('includes/scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN SCRIPTS JS -->

</body>
</html>