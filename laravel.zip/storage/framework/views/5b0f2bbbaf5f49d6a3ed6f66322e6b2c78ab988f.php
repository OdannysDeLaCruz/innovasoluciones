<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/media-query.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<title>Innova Soluciones | Cart </title>
</head>
<body>
	<?php if(session('response')): ?>
		<script>
			alert('Para ver los detalles del pedido, por favor añada productos al carrito');
		</script>
	<?php endif; ?>

	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->	
	<!-- SECCION CARRITO -->
	<section class="contenedor_carrito">
		<?php if(count($cart)): ?>
			<section class="carrito table table-responsive">
				<table class="table table-hover">
				  	<thead>
					    <tr class="carrito_titulo">
					      	<th>Imagen</th>
							<th>Descripción</th>
							<th>Precio Unitario ($)</th>
					      	<th>Cant</th>
							<th>Promoción <br> (Descuento)</th>
							<th>Total ($)</th>
					      	<th>*</th>
					    </tr>
				  	</thead>
				  	<tbody>
				  		<?php if(isset($cart)): ?>
					  		<?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  			<tr class="carrito_fila">
					  				<td scope="row">
					  					<a target="_blank" href="/productos/<?php echo e($carrito['producto_ref']); ?>-<?php echo e($carrito['descripcion']); ?>">
					  						<img class="carrito_fila_img" src="<?php echo e($carrito['imagen']); ?>" alt="<?php echo e($carrito['descripcion']); ?>">			
					  					</a>
						      		</td>
						      		<td class="carrito_fila_titulo">
						      			<p>
						      				<a target="_blank" href="/productos/<?php echo e($carrito['producto_ref']); ?>-<?php echo e($carrito['descripcion']); ?>">
						      					<?php echo e($carrito['descripcion']); ?>

						      				</a>
						      				<br>
						      				Color: <?php echo e($carrito['color']); ?> <br>
						      				Talla: <?php echo e($carrito['talla']); ?> 
								      	</p>					      					
						      		</td>
						      		<td class="carrito_fila_precio"><i>$<?php echo e(number_format($carrito['precio'], 0, ',', '.')); ?></i></td>
						      		<td class="carrito_fila_cantidad">
						      		<input 
						      			type="number" 
						      			min="1" 
						      			max="10" 
						      			value="<?php echo e($carrito['cantidad']); ?>"
						      			id="producto_<?php echo e($carrito['id']); ?>" 
						      		>
						      		<a 
						      			data-toggle="tooltip" 
						      			data-placement="top" 
						      			title="Actualizar cantidad"

						      			href="#"
						      			class="btn btn-primary btn-sm btn_actualizar_carrito"
						      			data-href="/cart/update/<?php echo e($carrito['id']); ?>"
						      			data-id="<?php echo e($carrito['id']); ?>" 	
						      		>
						      			<span  class="fa fa-refresh"></span>
						      		</a>
						      		<td class="carrito_fila_precio"><i><?php echo e($carrito['promocion']); ?></i></td>
						      		<td class="carrito_fila_precio"><i>$<?php echo e(number_format($carrito['total'], 0, ',', '.')); ?></i></td>
						      		</td>
						      		<td class="carrito_fila_borrar">
						      			<a href="<?php echo e(route('deleteItem', $carrito['id'])); ?>" data-toggle="tooltip" data-placement="top" title="Eliminar">
						      				<span class="fa fa-trash-o"></span>
						      			</a>
						      		</td>
					  			</tr>
					  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  		<?php endif; ?>
				  	</tbody>
				</table>
			</section>
			<div class="suma_total_carrito">
				<small>Total a pagar:</small>
				$<?php echo e(number_format( session('total_del_pedido'), 0, ',', '.')); ?> <br>
				<?php if(session('codigos_usados')): ?>
					<small style="font-size: 13px;">Usted utilizó el código <?php echo e(session('codigos_usados')); ?></small>
					
				<?php endif; ?>
			</div>
			
			<span class="carrito_botones">
				<div class="btn_carrito_vaciar botones_innova">
					<a href="<?php echo e(route('productos')); ?>"><span class="fa fa-arrow-left mr-2"></span> Seguir comprando</a>
				</div>
				<div class="btn_carrito_pagar botones_innova">
					<a href="<?php echo e(route('verificar')); ?>"><span class="fa fa-credit-card-alt"></span> Comprar</a>
				</div>
			</span>
		<?php else: ?> 
			<!-- Elimino el las variables de session codigos_usados, descuento_peso y notificacion_codigo si no hay algo en el carrito-->
			<?php
				session()->forget('codigos_usados');				
				session()->forget('descuento_peso');				
				session()->forget('notificacion_codigo');		
			?>

			<h1 class="msm_carrito_vacio"><?php echo e("No hay productos en el carrito"); ?></h1>
			<label class="carrito_botones">
				<div class="btn_seguir_comprando botones_innova">
					<a href="<?php echo e(route('productos')); ?>"><span class="fa fa-arrow-left mr-2"> </span> Ver productos</a>
				</div>
			</label>
		<?php endif; ?>
	</section>

	<!-- FIN SECCION CARRITO -->

	<!-- SECCION FOOTER -->
	<?php echo $__env->make('includes/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<!-- FIN FOOTER -->
	
	<!-- SECCION SCRIPTS JS -->
	<?php echo $__env->make('includes/scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN SCRIPTS JS -->
</body>
</html>