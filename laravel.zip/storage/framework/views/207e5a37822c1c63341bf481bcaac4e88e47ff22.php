<?php 

$ApiKey = "4Vj8eK4rloUd272L48hsrarnUA";
$shipping_city = $_REQUEST['shipping_city'];

return $shipping_city;

?>