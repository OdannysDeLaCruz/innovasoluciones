<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos_admin.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/media-query.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<title> <?php echo $__env->yieldContent('title'); ?> | Innova Soluciones</title>
</head>
<body>
	
	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->


	<section class="contenedor_panel_admin row">
		<!-- SECCION MENU LATERAL ADMIN -->
		<?php echo $__env->make('admin/modulos/menu_lateral_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- FIN MENU LATERAL ADMIN -->

		<!-- SECCION CONTENIDO PRINCIPAL -->
		<?php echo $__env->yieldContent('contenido'); ?>
		<!-- FIN CONTENIDO PRINCIPAL -->
		
	</section>


	<!-- SECCION FOOTER -->
	<?php echo $__env->make('includes/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN FOOTER -->

	<!-- SECCION SCRIPTS JS -->
	<?php echo $__env->make('includes/scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN SCRIPTS JS -->
</body>
</html>