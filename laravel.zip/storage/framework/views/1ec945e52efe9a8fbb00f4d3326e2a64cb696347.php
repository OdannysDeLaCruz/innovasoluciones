	<?php $__env->startSection('script-local'); ?> 
		<script src="https://cdn.ckeditor.com/4.12.1/full/ckeditor.js"></script>
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('title'); ?> 
		Crear nuevo producto
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('productos'); ?> active <?php $__env->stopSection(); ?>
	<?php $__env->startSection('contenido'); ?>
		
		<section class="col-12 col-md-10 contenido_principal">
			<header class="encabezado_principal">
				<h1 class="titulo_principal">productos / crear producto</h1>
			</header>
			
			<section class="contenedor_tabla">
				<form class="form_crear_producto" id="form_crear_producto" action="<?php echo e(route('storeProduct')); ?>" method="post" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>



					<!-- Información basica del producto -->
					<section class="form-group">
						<h1 class="form-group-titulo">Información básica del producto</h1>
						<div class="form-group-blocks row">

							<!-- Nombre -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="nombre">
									<span class="form_titulos_required">*</span>Nombre del producto
								</label>

								<input autofocus type="text" id="nombre" class="form-control" name="producto_nombre" value="<?php echo e(old('producto_nombre')); ?>" >

								<?php if($errors->has('producto_nombre')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('producto_nombre')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Precio -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="precio">
									<span class="form_titulos_required">*</span>Precio
									<span class="precio-preview">
										<span>COP$ </span><span id="precioPreview"></span>
									</span>
								</label>

								<input type="text" id="precio" class="form-control" name="precio" value="<?php echo e(old('precio')); ?>">
								<small class="text-muted">Este precio debe tener impuestos incluidos</small>

								<?php if($errors->has('precio')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('precio')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Cantidad -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="cantidad">
									<span class="form_titulos_required">*</span>Cantidad
								</label>

								<input type="number" min="1" id="cantidad" class="form-control" name="cantidad" value="<?php echo e(old('cantidad')); ?>" >

								<?php if($errors->has('cantidad')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('cantidad')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Categoria -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="categoria">
									<span class="form_titulos_required">*</span>Categoria
								</label>

								<select class="form-control" id="categoria" name="categoria" value="<?php echo e(old('categoria')); ?>" >
									<?php if(isset($categorias)): ?>
										<option>Escoge una categoria</option>
										<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if(old('categorias') == $categoria->id ): ?>
												<option value="<?php echo e($categoria->id); ?>" selected><?php echo e($categoria->categoria_nombre); ?></option>
											<?php else: ?>
												<option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->categoria_nombre); ?></option>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php else: ?>
										<option></option>
									<?php endif; ?>
								</select>

								<?php if($errors->has('categoria')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('categoria')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Descripción -->
							<div class="form-group-blocks-item col-12">
								<label class="form-group-subtitulo">
									<span class="form_titulos_required">*</span>Descripción del producto
								</label>
								<textarea name="descripcion"><?php echo e(old('descripcion')); ?></textarea>
							</div>
						</div>						
					</section>

					<!-- Detalles del producto -->
					<section class="form-group">
						<h1 class="form-group-titulo">Detalles del producto</h1>
						<div class="form-group-blocks row">

							<!-- Tallas -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="tallas">
									<span class="form_titulos_required"></span>Tallas <small class="text-muted">(separe las tallas ó tamaños con una " , ")</small>
								</label>

								<input autofocus type="text" id="tallas" class="form-control" name="tallas" value="<?php echo e(old('tallas')); ?>">

								<?php if($errors->has('tallas')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('tallas')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Colores -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="colores">
									<span class="form_titulos_required"></span>Colores <small class="text-muted">(separados por " , ")</small>
								</label>

								<input type="text" id="colores" class="form-control" name="colores" value="<?php echo e(old('colores')); ?>">

								<?php if($errors->has('colores')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('colores')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Proveedor -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="proveedor">
									<span class="form_titulos_required"></span>Proveedor
								</label>

				                <select class="form-control" id="proveedor" name="proveedor" value="<?php echo e(old('proveedor')); ?>">
									<option value="0">Asigna un proveedor</option>
									<?php if(isset($proveedores)): ?>
										<?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if(old('proveedor') == $proveedor->id ): ?>
												<option value="<?php echo e($proveedor->id); ?>" selected><?php echo e($proveedor->proveedor_razon_social); ?></option>
											<?php else: ?>
												<option value="<?php echo e($proveedor->id); ?>"><?php echo e($proveedor->proveedor_razon_social); ?></option>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>

								</select>

								<?php if($errors->has('proveedor')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('proveedor')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Marca -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="marca">
									<span class="form_titulos_required"></span>Marca
								</label>

				                <select class="form-control" id="marca" name="marca" value="<?php echo e(old('marca')); ?>">
									<option value="0">Asigna una marca</option>
									<?php if(isset($marcas)): ?>
										<?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if(old('marca') == $marca->id ): ?>
												<option value="<?php echo e($marca->id); ?>" selected><?php echo e($marca->marca_nombre); ?></option>
											<?php else: ?>
												<option value="<?php echo e($marca->id); ?>"><?php echo e($marca->marca_nombre); ?></option>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</select>

								<?php if($errors->has('marca')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('marca')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Etiquetas -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="tags">
									<span class="form_titulos_required">*</span>Etiquetas <small class="text-muted">(presione tecla space para confirmar, toca las etiquetas para quitarlas)</small>
								</label> 

								<div class="tags-preview" id="tags-preview"></div>

								<input type="text" id="tagsInput" class="form-control tags-input" name="tags" value="<?php echo e(old('tags')); ?>" >

								<input type="hidden" id="tags" class="form-control" name="etiquetas" value="<?php echo e(old('etiquetas')); ?>" required>

								<?php if($errors->has('etiquetas')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('etiquetas')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
						</div>						
					</section>

					<!-- Multimedia -->
					<section class="form-group">
						<h1 class="form-group-titulo">Información Multimedia del producto</h1>
						<div class="form-group-blocks row">

							<!-- Imagen de Portada -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="portada">
									<span class="form_titulos_required">*</span>Imagen de portada
								</label>

								<input type="file" class="form-control" id="portada" name="portada" value="<?php echo e(old('portada')); ?>" >

								<?php if($errors->has('portada')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('portada')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Imagenes complementarias -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="imagenes">
									<span class="form_titulos_required"></span>Imagenes complementarias
								</label>

								<input type="file" class="form-control" name="imagenes[]" multiple>
								
								<?php if($errors->has('imagenes')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('imagenes')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>
							<!-- Videos de complementarios -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="videos">
									<span class="form_titulos_required"></span>Videos complementarios <br> <small>Insertar código de YouTube</small>
								</label>

								<textarea rows="5" id="videos" class="form-control" name="videos" placeholder="Separados por comas ( , )"><?php echo e(old('videos')); ?></textarea>

								<?php if($errors->has('videos')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('videos')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>

							<!-- Checkbox descripcion por imagen -->
							<div class="form-group-blocks-item col-12 col-sm-6">
						
								<label class="form-group-subtitulo descripcion_por_imagen" for="img_descrip">
									<span class="form_titulos_required"></span>¿Descripción por imagen?
								</label>

								<?php if( old('descripcion_por_imagen') == 'on' ): ?>
									<input type="checkbox" id="img_descrip" class="checkbox" name="descripcion_por_imagen" checked>
								<?php else: ?>
									<input type="checkbox" id="img_descrip" class="checkbox" name="descripcion_por_imagen">
								<?php endif; ?>
							</div>
						</div>
					</section>

					<!-- Promociones -->
					<section class="form-group">
						<h1 class="form-group-titulo">Impuestos, promociones y agregados</h1>
						<div class="form-group-blocks row">

							<!-- Promociones -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="promocion">
									<span class="form_titulos_required"></span>Agregar promoción
								</label>
				                <select class="form-control" id="promocion" name="promocion" value="<?php echo e(old('promocion')); ?>">
				                	<option value="0">Escoge una promoción</option>
									<?php if(isset($promociones)): ?>
										<?php $__currentLoopData = $promociones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promocion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if(old('promocion') == $promocion->id ): ?>
												<option value="<?php echo e($promocion->id); ?>" selected>
													<?php echo e($promocion->promo_nombre . '($texto)'); ?>

													(
														<?php if($promocion->promo_tipo == "%"): ?>
															<?php echo e($promocion->promo_costo . '%'); ?>

														<?php elseif($promocion->promo_tipo == "$"): ?>
															<?php echo e('COP$ '. number_format($promocion->promo_costo, 0, '', '.')); ?>

														<?php else: ?>
															<?php echo e('2x1'); ?>

														<?php endif; ?>
													)
												</option>
											<?php endif; ?>
												<option value="<?php echo e($promocion->id); ?>">
													<?php echo e($promocion->promo_nombre); ?> 
													(
														<?php if($promocion->promo_tipo == "%"): ?>
															<?php echo e($promocion->promo_costo . '%'); ?>

														<?php elseif($promocion->promo_tipo == "$"): ?>
															<?php echo e('COP$ '. number_format($promocion->promo_costo, 0, '', '.')); ?>

														<?php else: ?>
															<?php echo e('2x1'); ?>

														<?php endif; ?>
													)
												</option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</select>
								<?php if($errors->has('promocion')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('promocion')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>

							<!-- Costo de envio -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="costo_envio">
									<span class="form_titulos_required"></span>Costo de envío 
									<span class="costo_envio-preview">
										<span>COP$ </span>
										<span id="costo_envioPreview"></span>
									</span>
								</label>

								<input type="text" id="costo_envio" class="form-control" name="costo_envio" value="<?php echo e(old('costo_envio')); ?>" >				

								<?php if($errors->has('costo_envio')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('costo_envio')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>

							<!-- Ganancias -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo" for="ganancias">
									<span class="form_titulos_required"></span>Ganancias en %
								</label>	

								<select class="form-control" id="ganancias" name="ganancias" value="<?php echo e(old('ganancias')); ?>">
									<?php $__currentLoopData = $ganancias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ganancia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if(old('ganancias') == $key): ?>
											<option value="<?php echo e($key); ?>" selected><?php echo e($ganancia); ?></option>
										<?php else: ?>
											<option value="<?php echo e($key); ?>"><?php echo e($ganancia); ?></option>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>

								<?php if($errors->has('ganancias')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('ganancias')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>


							<!-- Iva -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo iva" for="iva">
									<span class="form_titulos_required"></span>Agregar impuesto IVA del 19%
								</label>

								<?php if( old('iva') == 'on' ): ?>
									<input type="checkbox" id="iva" class="checkbox-iva" name="iva" checked>
								<?php else: ?>
									<input type="checkbox" id="iva" class="checkbox-iva" name="iva">
								<?php endif; ?>


								<?php if($errors->has('iva')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('iva')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>

							<!-- Payu -->
							<div class="form-group-blocks-item col-12 col-sm-6">
								<label class="form-group-subtitulo payu" for="payu">
									<span class="form_titulos_required"></span>Agregar comisión Payu 3.49% + 900
								</label>

								<?php if( old('payu') == 'on' ): ?>
									<input type="checkbox" id="payu" class="checkbox-payu" name="payu" checked>
								<?php else: ?>
									<input type="checkbox" id="payu" class="checkbox-payu" name="payu">
								<?php endif; ?>


								<?php if($errors->has('payu')): ?>
				                    <span class="invalid-feedback" role="alert">
				                        <p><?php echo e($errors->first('payu')); ?></p>
				                    </span>
				                <?php endif; ?>
							</div>

							
													
						</div>						
					</section>

					<!-- Barra de aceptar registro o cancelar registro -->

					<div class="form-group form_botones_accion">
						<button type="submit" class="boton-defaul-verde" id="btn-crear-producto"> Crear producto </button>
					</div>
				</form>
			</section>
		</section>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>