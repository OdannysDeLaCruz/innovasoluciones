<section class="seccion_nuevos">
	<label class="seccion_categorias_textos">
		<h1 class="seccion_nuevos_titulo">
			PRODUCTOS NUEVOS 
			<span class="estrellas">
				<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
			</span>
		</h1>
	</label>
	<div class="seccion_nuevos_carrusel">
		
		<?php $__currentLoopData = $productos_nuevos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nuevos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php 
				$ref  = $nuevos['producto_ref'];
				$desc = str_replace(" ", "-", $nuevos['producto_descripcion']);
			?>
			<section class="producto">
				<figure>
					<a href="/productos/<?php echo e($ref); ?>-<?php echo e($desc); ?>">
						<img src="<?php echo e($nuevos['producto_imagen']); ?>" class="producto_img" alt="<?php echo e($nuevos['producto_descripcion']); ?>">
					</a>
				</figure>
				<div class="producto_info">
					<a href="/productos/<?php echo e($ref); ?>-<?php echo e($desc); ?>">
						<h1 class="producto_titulo"> <?php echo e($nuevos['producto_descripcion']); ?></h1>
					</a>

					<?php if($nuevos['promo_tipo'] == 'descuento%'): ?>
						<span class="producto_precio_anterior">
							<p class="descuento">
								-<?php echo e($nuevos['promo_costo']); ?>%
							</p>
							<p class="precio_anterior"> $<?php echo e(number_format($nuevos['producto_precio'], 0, ',', '.')); ?> </p>
						</span>

					<?php elseif($nuevos['promo_tipo'] == 'peso'): ?>
						<span class="producto_precio_anterior">
							<p class="descuento">
								-$<?php echo e(number_format($nuevos['promo_costo'], 0, ',', '.')); ?>							
							</p>
							<p class="precio_anterior"> $<?php echo e(number_format($nuevos['producto_precio'], 0, ',', '.')); ?> </p>
						</span>
					<?php elseif($nuevos['promo_tipo'] == '2x1'): ?>
						<span class="producto_precio_anterior">
							<p class="descuento">
								<?php echo e($nuevos['promo_tipo']); ?>					
							</p>
						</span>
					<?php endif; ?>
				</div>

				<label class="producto_precio">
					<?php
					if($nuevos['promo_tipo'] == 'descuento%') {
						$descuento = $nuevos['producto_precio'] * ($nuevos['promo_costo'] / 100);
						$total = $nuevos['producto_precio'] - $descuento;
					}
					elseif($nuevos['promo_tipo'] == 'peso'){
						$total = $nuevos['producto_precio'] - $nuevos['promo_costo'];
					}
					else {
						$total = $nuevos['producto_precio'];
					}
					?>
					<p>$<?php echo e(number_format($total, 0, ',', '.')); ?> </p>		
				</label>
				
			</section>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>
</section>