<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
	<link rel="stylesheet" type="text/css" href="css/media-query.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<title> Verificación | Innova Soluciones</title>
</head>
<body>
	
	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->

	<!-- SECCION DE PAYMENT -->
	<section class="contenedor_payment row">
		<!-- Div para hacer un layout -->
		<div class="col-md-8 seccion_payment_proceso">
			<section id="detalles" class="payment_proceso payment_activo">
				<h1 class="payment_titulos">Detalles del pedido</h1>		
				<section class="payment_proceso_tarjeta tarjeta_detalle_pedido">
					<?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<section class="pedido">
							<a target="_blank" href="/productos/<?php echo e($carrito['id']); ?>-<?php echo e($carrito['descripcion']); ?>">
								<img class="pedido_img" src="<?php echo e($carrito['imagen']); ?>">						
							</a>
							<div class="pedido_info">
								<a target="_blank" href="/productos/<?php echo e($carrito['id']); ?>-<?php echo e($carrito['descripcion']); ?>">
									<h1 class="pedido_info_nombre"><?php echo e($carrito['descripcion']); ?></h1>
								</a>
								<label class="pedido_info_precio">
									Precio: <b>$<?php echo e(number_format($carrito['precio'], 2)); ?> </b>
								</label>
								<label class="pedido_info_cantidad">
									Cantidad: <b><?php echo e($carrito['cantidad']); ?></b>
								</label>
								<?php if($carrito['promocion'] != ''): ?>
									<label class="pedido_info_precio">
										Descuento: <b> <?php echo e($carrito['promocion']); ?> </b>
									</label>								
								<?php endif; ?>
								<label class="pedido_info_precio">
									Total: <b>$<?php echo e(number_format($carrito['total'], 2)); ?> </b>
								</label>
							</div>
						</section>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</section>
				<section id="tarjeta_codigo_descuento" class="payment_proceso_tarjeta tarjeta_codigo_descuento">
					<div class="codigo_descuento" id="codigo_descuento">
						<form action="<?php echo e(route('verificarCodigo')); ?>" method="POST" >
							<?php echo e(csrf_field()); ?>

							<div class="form-group 
								d-flex
								flex-column
								flex-sm-row
								justify-content-around
								justify-content-sm-end 
								align-items-center
								justify-content-end	
								">
								
								<?php if(session('Errors')): ?> 
									<script>
										alert(" <?php echo e(session('Errors')); ?> ");
									</script>
								<?php endif; ?>
								
								<label style="margin: 0;" for="codigo">
									¿Tienes algún código de descuento? 
									<small class="text-muted">(opcional)</small>
								</label>
								
								<input type="text" id="codigo" name="codigo_descuento" value="<?php echo e(session('codigo_verificado') ? session('codigo_verificado') : ''); ?>" required>

								<button type="submit" class="btn_enviar_codigo mt-1 mt-sm-0" name="verificarCodigo">
									Descontar
								</button>
							</div>
							<?php if(session('Errors')): ?>
				                <span class="invalid-feedback" role="alert" style="font-size: 15px;">
				                    <strong><?php echo e(session('Errors')); ?></strong>
				                </span>
			                <?php endif; ?>
						</form>
					</div>			
					<!-- Si el descuento se realiza correctamente, envio un msm y oculto el bloque codigo_descuento -->
					<?php if(session('descuento_realizado') == true): ?>
						<?php if(session('noticia_descuento')): ?>
							<script>
								alert(" <?php echo e(session('noticia_descuento')); ?> ");
							</script>
						<?php endif; ?>
						<script>
							document.getElementById('tarjeta_codigo_descuento').style.display = "none";				
						</script>

						<span class="valid-feedback">
		                    <strong><?php echo e(session('noticia_descuento')); ?></strong>
		                </span>					
					<?php endif; ?>
					<!-- Si hay mas de un codigo usado, oculto el bloque codigo_descuento -->
					<?php if(session('codigos_usados') > 1): ?>
						<script>
							document.getElementById('codigo_descuento').style.display = "none";
						</script>
					<?php endif; ?>
				</section>
				<section class="payment_proceso_tarjeta tarjeta_botones_pedidos">
					<div class="pedidos_botones">
						<div class="pedidos_botones_btn botones_innova">
							<a href="<?php echo e(route('productos')); ?>"><i class="fa fa-arrow-left"></i>Seguir comprando</a>
						</div>
						<div class="pedidos_botones_btn botones_innova">
							<a id="btn_siguiente" href="#">Siguiente <i class="fa fa-arrow-right"></i></a>
						</div>
					</div>			
				</section>			
			</section>
			<section id="datos_envio" class="payment_proceso payment_envio">
				<h1 class="payment_titulos">¿Donde quieres recibirlo?</h1>
				<small>Si deseas recibir el pedido a otra dirección cambiela desde su cuenta de perfil.</small>

				<section class="payment_proceso_tarjeta tarjeta_direccion_envio">
					<div class="direccion_envio">
						<span class="fa fa-map-marker direccion_envio_icono"></span>
						<span class="direccion_envio_texto">
							<b> <?php echo e(Auth::user()->usuario_direccion); ?> </b>
							<small>
								<?php echo e(Auth::user()->usuario_barrio); ?> - <?php echo e(Auth::user()->usuario_ciudad); ?> - <?php echo e(Auth::user()->usuario_pais); ?>							
							</small>
						</span>
					</div>
					<a href="<?php echo e(route('perfil')); ?>" class="direccion_link">Editar esta dirección</a>
				</section>

				<h1 class="payment_titulos">¿Como desea recibir el pedido?</h1>

				<section class="payment_proceso_tarjeta tarjeta_tipo_envio">
					<?php if($tipo_entregas): ?>
						<?php $__currentLoopData = $tipo_entregas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<section class="tarjeta_envio_domicilio">
								<form class="form_opcion_envio" action="<?php echo e(route('payment')); ?>" method="POST">
									<?php echo e(csrf_field()); ?> 
									<input type="hidden" name="tipo_entrega" value="<?php echo e($tipo->id); ?>">
									<button class="btn_opcion_envio">
										<span class="text_opcion_envio">
											<?php echo e($tipo->envio_metodo); ?> <br>

											<?php if($tipo->envio_metodo == 'Tienda fisica'): ?>
												<small style="color: #333;">Calle 6 # 42-90 Valledupar - Colombia</small>												
											<?php endif; ?>
										</span>
									</button>
								</form>
							</section>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>				
				</section>

				<section class="payment_proceso_tarjeta tarjeta_ver_detalle_pedido">
					<div class="botones_innova">
						<a id="btn_ver_detalles" href="#">
							<i class="fa fa-arrow-left mr-2"></i>
							Ver detalles
						</a> 
					</div>
				</section>				
			</section>			
		</div>
		<div class="col-md-4 seccion_resumen_pedido">
			<section class="payment_proceso_tarjeta tarjeta_resumen_pedido">
				<span class="payment_proceso_tarjeta titulo_resumen_table">
					<strong>Resumen del pedido</strong>
				</span>
				<table class="table table-bordered resumen_table">
					<tr>
				    	<th>Productos (<?php echo e($cantidad_productos); ?>)</th>
				    	<td>$<?php echo e(number_format( $total_del_pedido, 0, ',', '.')); ?></td>
				  	</tr>
				  	<?php if($descuento_peso > 0): ?>
				  	<tr>
				    	<th>Descuento por código</th>
				    	<td>$<?php echo e(number_format( $descuento_peso, 0, ',', '.')); ?></td>
				  	</tr>
				  	<?php endif; ?>
				  	<tr>
				    	<th style="font-weight: 400;">TOTAL A PAGAR</th>
				    	<td>$<?php echo e(number_format($total_pagar, 0, ',', '.')); ?></td>
				  	</tr>
				</table>
			</section>
		</div>
	</section>
	<!-- FIN SECCION DE PAYMENT -->
	
	<!-- SECCION FOOTER -->
	<?php echo $__env->make('includes/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<!-- FIN FOOTER -->
	
	<!-- SECCION SCRIPTS JS -->
	<?php echo $__env->make('includes/scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN SCRIPTS JS -->

</body>
</html>