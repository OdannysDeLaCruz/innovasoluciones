<section class="content_menu_lateral_admin col-12 col-md-2">
	<nav class="menu_lateral_admin">
		<ul>
			<span class="avatar_usuario">
				<img src="<?php echo e(asset('uploads/avatars/avatar.png')); ?>">
				<h1 class="avatar_usuario_nombre"><?php echo e(Auth::user()->usuario_nombre . ' ' . Auth::user()->usuario_apellido); ?> </h1>
			</span>
			<hr style="width: 100%; margin-top: 0;">
			<li class="items  <?php echo $__env->yieldContent('inicio'); ?>">
				<span class="items_icon fas fa-tachometer-alt"></span>
				<span class="items_text">inicio</span>
				<a href="<?php echo e(route('admin')); ?>" class="items_link"></a>
			</li>
			<li class="items  <?php echo $__env->yieldContent('productos'); ?>">
				<span class="items_icon fa fa-cubes"></span>
				<span class="items_text">productos</span>				
				<a href="<?php echo e(route('getProducts')); ?>" class="items_link"></a>
			</li>
			<li class="items  <?php echo $__env->yieldContent('pedidos'); ?>">
				<span class="items_icon fa fa-shopping-bag"></span>
				<span class="items_text">pedidos</span>				
				<a href="<?php echo e(route('getPedidos')); ?>" class="items_link"></a>
			</li>
			<li class="items  <?php echo $__env->yieldContent('clientes'); ?>">
				<span class="items_icon fa fa-users"></span>	
				<span class="items_text">clientes</span>
				<a href="<?php echo e(route('getClientes')); ?>" class="items_link"></a>
			</li>
			<li class="items  <?php echo $__env->yieldContent('codigos'); ?>">
				<span class="items_icon fas fa-ticket-alt"></span>
				<span class="items_text">códigos de descuento</span>				
				<a href="<?php echo e(route('getCodigos')); ?>" class="items_link"></a>
			</li>
			<li class="items  <?php echo $__env->yieldContent('secciones'); ?>">
				<span class="items_icon fa fa-columns"></span>
				<span class="items_text">secciones</span>
				<a href="<?php echo e(route('getSecciones')); ?>" class="items_link"></a>
			</li>
			<li class="items  <?php echo $__env->yieldContent('categorias'); ?>">
				<span class="items_icon fa fa-th-list"></span>
				<span class="items_text">categorías</span>
				<a href="<?php echo e(route('getCategorias')); ?>" class="items_link"></a>
			</li>
			<li class="items  <?php echo $__env->yieldContent('usuarios'); ?>">
				<span class="items_icon fas fa-user-cog"></span>
				<span class="items_text">usuarios del sistema</span>
				<a href="<?php echo e(route('getUsuarios')); ?>" class="items_link"></a>
			</li>
			<hr style="width: 100%">
			<li class="items link-visitar-pagina">
				<!-- <span class="items_icon fa fa-share-square-o"></span> -->
				<span class="items_icon fas fa-external-link-alt"></span>
				<span class="items_text">Visitar sitio web</span>
				<a href="<?php echo e(route('home')); ?>" class="items_link"></a>
			</li>
		</ul>
	</nav>
</section>