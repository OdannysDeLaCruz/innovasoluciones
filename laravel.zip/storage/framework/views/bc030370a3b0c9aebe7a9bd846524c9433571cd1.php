	<?php $__env->startSection('title'); ?> 
		Usuarios del sistema
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('usuarios'); ?> active <?php $__env->stopSection(); ?>
	<?php $__env->startSection('contenido'); ?> 
		<section class="col-10 col-sm-10 col-md-10 contenido_principal">
			<header class="encabezado_principal">
				<h1 class="titulo_principal">Usuarios</h1>
			</header>
		</section>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>