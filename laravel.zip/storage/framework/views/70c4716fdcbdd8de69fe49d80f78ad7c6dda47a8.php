<div class="footer">
	<img src="<?php echo e(asset('img/factura/footer-factura.png')); ?>">
</div>