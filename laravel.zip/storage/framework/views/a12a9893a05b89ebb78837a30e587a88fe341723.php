<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/media-query.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<title> Facturas | Usuario </title>
</head>
<body>

	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->

	<!-- SECCION PERFIL -->
	
		<?php $__env->startSection('facturas'); ?> active <?php $__env->stopSection(); ?>
		<?php $__env->startSection('content'); ?>
			<section class="col-xs-12 col-md-10 facturas">
				<h1 class="perfil_info_titulo mt-2 mb-4">Mis facturas</h1>

			<?php if($pedidos !== ''): ?>
				<div class="contenedor_table facturas_pendientes table table-responsive">					
					<table class="table table-hover table-bordered">
						<thead>
							<tr class="facturas_titulos">
								<th>Ref. pedido</th>
								<th class="d-none d-md-table-cell">Fecha de la factura</th>
								<th>Total</th>
								<th>Detalles</th>
								<th>Estado</th>
							</tr>
						</thead>
					<?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tbody>
							<tr class="facturas_datos">
								<td><?php echo e($pedido['ref_venta']); ?></td>
								<td class="d-none d-md-table-cell"><?php echo strftime('%A, %d de %B de %Y - %H:%M', strtotime($pedido['fecha_creado'])); ?></td>
								<td class="facturas_datos_precio">COP$ <?php echo e(number_format($pedido['total'], 0, '', '.')); ?></td>
								<td>
									<a target="_blanc" href="<?php echo e(route('detalle_factura', $pedido['id'])); ?>">Ver</a> | 
									<a href="<?php echo e(route('descargar_factura', $pedido['id'])); ?>">Descargar</a>
								</td>
								<td class="facturas_datos_estado">
									<?php if($pedido['estado'] == 0 || $pedido['estado'] == ''): ?>
										<p class="estados pedidos_estado_espera"> <?php echo e("En espera"); ?> </p>	
									<?php elseif($pedido['estado'] == 4): ?> 
										<p class="estados pedidos_estado_aprovada"> <?php echo e("Aprovado"); ?> </p>
									<?php elseif($pedido['estado'] == 6): ?> 
										<p class="estados pedidos_estado_declinada"> <?php echo e("Declinada"); ?> </p>
									<?php elseif($pedido['estado'] == 5): ?>
										<p class="estados pedidos_estado_expirada"> <?php echo e("Expirada"); ?> </p>
									<?php endif; ?>	
								</td>
							</tr>
						</tbody>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
				</div>
			<?php else: ?>
				<?php echo e('Todo en orden por aquí'); ?>

			<?php endif; ?>

			</section>			
		<?php $__env->stopSection(); ?>
	<!-- FIN PERFIL -->
</body>
</html>
<?php echo $__env->make('users/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>