<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/media-query.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<title> Productos | Confirmación de su compra</title>
</head>
<body>
	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->
	<?php if(strtoupper($firma) == strtoupper($firmacreada)): ?>

		<section class="payment_proceso_tarjeta respuesta_trans">
			<section class="payment_proceso_tarjeta respuesta_trans_txt">
				<?php if($transactionState == 4): ?>
					<h1 class="respuesta_trans_txt_titulo"><?php echo e($estadoTx); ?></h1>
					<span style="
					color:orange; 
					border: 8px solid #39E245;" 
					class="fa fa-check icono_respuesta"></span>					
				<?php elseif($transactionState == 7): ?>
					<h1 class="respuesta_trans_txt_titulo"><?php echo e($estadoTx); ?></h1>
					<p style="
					font-size: 15px; 
					text-align: center;"
					class="text-muted">Nos pondremos en contacto con usted cuando haya respuesta de su pago.</p>
					<span style="color:orange; border: 8px solid orange;" class="fa fa-check icono_respuesta"></span>
				<?php endif; ?>

				<h1 class="respuesta_trans_txt_transaccion"><strong>Transacción: </strong><?php echo e($reference_pol); ?></h1>
				<h1 class="respuesta_trans_txt_refventa"><strong>Ref. venta: </strong><?php echo e($referenceCode); ?></h1>
			</section>
			<section class="payment_proceso_tarjeta respuesta_trans_table">
				<section class="respuesta_trans_table_costo">$<?php echo e(number_format($TX_VALUE, 0, ',', '.')); ?> <?php echo e($currency); ?></section>
				<h1 class="respuesta_trans_table_titulo">Detalles de su compra</h1>
				<table class="table table-bordered">

					<?php if($pseBank != null): ?>		
						<tr>
							<td>cus </td>
							<td><?php echo e($cus); ?></td>
						</tr>
						<tr>
							<td>Banco </td>
							<td><?php echo e($pseBank); ?></td>
						</tr>
					<?php endif; ?>
					<tr>
						<td>Descripción de venta</td>
						<td><?php echo e($extra1); ?></td>
					</tr>
					<tr>
						<td>Dirección de envio</td>
						<td><?php echo e($direccion_envio); ?></td>
					</tr>
					<tr>
						<td>Forma de entrega</td>
						<td><?php echo e($forma_entrega); ?></td>
					</tr>
					<tr>
						<td>Medio de pago</td>
						<td><?php echo e($lapPaymentMethod); ?> <?php echo e($lapPaymentMethodType); ?></td>
					</tr>
					<tr>
						<td>Fecha</td>
						<td></td>
					</tr>
				</table>
			</section>
			<section class="respuesta_trans_btn_opcion">
				<button>
					<a href="<?php echo e(route('productos')); ?>">Ver mas productos</a>				
				</button>
				<button>
					<a href="<?php echo e(route('pedidos')); ?>">Ver mis compras</a>
				</button>
			</section>
		</section>
	
	<?php else: ?>
		<section class="payment_proceso_tarjeta">
			<h1>Error validando firma digital.</h1>		
		</section>
	<?php endif; ?>


	<!-- SECCION FOOTER -->
	<?php echo $__env->make('includes/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<!-- FIN FOOTER -->
	
	<!-- SECCION SCRIPTS JS -->
	<?php echo $__env->make('includes/scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN SCRIPTS JS -->
	
</body>
</html>

