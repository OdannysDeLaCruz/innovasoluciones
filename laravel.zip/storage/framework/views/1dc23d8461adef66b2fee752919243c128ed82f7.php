<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
	<link rel="stylesheet" type="text/css" href="css/media-query.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<title> Register | Innova Soluciones </title>
</head>
<body>
	
	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->
	
	<!-- SECCION DE FORMULARIO DE REGISTRO -->
	<div class="contenedor_registro">
		<form class="form_registro" method="POST" action="<?php echo e(route('register')); ?>">
			<?php echo e(csrf_field()); ?> 
			<figure>
				<img class="form_registro_logo" src="img/logos/LogoInnova.svg">
			</figure>
			<h1 class="form_registro_titulo">Hola, registrate para empezar a comprar.</h1>
			<div class="form_registro_grupo">
				<div class="nombre_apellido row">
					<div class="user col-xs-12 col-md-6">
						<!-- NOMBRE -->
						<label for="nombre" class="texto mt-4 mt-md-0">Nombre</label>
						<input id="nombre" type="text" class="nombre <?php echo e($errors->has('usuario_nombre') ? ' is-invalid' : ''); ?>" name="usuario_nombre" value="<?php echo e(old('usuario_nombre')); ?>" required placeholder="Digite su nombre">

		                <?php if($errors->has('usuario_nombre')): ?>
		                    <span class="invalid-feedback" role="alert">
		                        <strong><?php echo e($errors->first('usuario_nombre')); ?></strong>
		                    </span>
		                <?php endif; ?>
					</div>

	                <div class="user col-xs-12 col-md-6 pl-md-2">
		                <!-- APELLIDO -->
						<label for="apellido" class="texto mt-4 mt-md-0">Apellido</label>
						<input id="apellido" type="text" class="apellido <?php echo e($errors->has('usuario_apellido') ? ' is-invalid' : ''); ?>" name="usuario_apellido" value="<?php echo e(old('usuario_apellido')); ?>" required placeholder="Digite su apellido">

		                <?php if($errors->has('usuario_apellido')): ?>
		                    <span class="invalid-feedback" role="alert">
		                        <strong><?php echo e($errors->first('usuario_apellido')); ?></strong>
		                    </span>
		                <?php endif; ?>	                	
	                </div>
				</div>

				<!-- Nº DOCUMENTO -->
				<label class="texto"></label>
				<input id="usuario_cedula" type="number" class="num_documento <?php echo e($errors->has('usuario_cedula') ? ' is-invalid' : ''); ?>" name="usuario_cedula" value="<?php echo e(old('usuario_cedula')); ?>" required placeholder="Nº de documento">

                <?php if($errors->has('usuario_cedula')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('usuario_cedula')); ?></strong>
                    </span>
                <?php endif; ?>

                <!-- TELEFONO -->
				<label class="texto"></label>
				<input id="usuario_telefono" type="number" class="num_documento <?php echo e($errors->has('usuario_telefono') ? ' is-invalid' : ''); ?>" name="usuario_telefono" value="<?php echo e(old('usuario_telefono')); ?>" required placeholder="Digite su número de teléfono ó celular">

                <?php if($errors->has('usuario_telefono')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('usuario_telefono')); ?></strong>
                    </span>
                <?php endif; ?>

				<!-- EMAIL -->
				<label for="email" class="texto">E-mail</label>
				<input id="email" type="email" class="email <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required placeholder="Correo electrónico">
				<small class="msm_email">No compartiremos este email con nadie mas</small>

				<?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>

				<!-- PASSWORD -->
				<label for="password" class="texto">Contraseña</label>
				<input id="password" type="password" class="password <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" name="password" value="<?php echo e(old('password')); ?>" min="6" max="15" required placeholder="Minimo 6 caracteres">

				<?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
				
				<!-- PASSWORD CONFIRMED -->
                <label for="password" class="texto">Confirmar contraseña</label>
				<input id="password-confirm" type="password" class="password" name="password_confirmation" placeholder="Repita su contraseña">

				<label class="aceptar_terminos">
					Al registrarme, declaro que soy mayor de edad y acepto los <a href="terminos">Terminos y Condiciones de Innova Soluciones</a>
				</label>
				<button type="submit" class="btn_registrarse">Registrarme</button>
				<label class="ya_tengo_cuenta">
					<p>Ya tengo una cuenta <a href="<?php echo e(route('login')); ?>">Iniciar sesión</a></p>					
				</label>
			</div>
		</form>
	</div>
	<!-- FIN SECCION DE FORMULARIO DE REGISTRO

	
	<!-- SECCION FOOTER -->
	<?php echo $__env->make('includes/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<!-- FIN FOOTER -->
	
	<!-- SECCION SCRIPTS JS -->
	<?php echo $__env->make('includes/scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN SCRIPTS JS -->
</body>
</html>