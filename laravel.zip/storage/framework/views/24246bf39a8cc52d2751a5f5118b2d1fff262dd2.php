<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<h1>Hola, Factura</h1>
	<?php $var = 'Esta es mi factura' ?>
	<h2><?php echo e($var); ?></h2>
</body>
</html>