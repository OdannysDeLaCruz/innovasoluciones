<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>" >

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/media-query.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<title> Detalles por referencias - opción de compra | Innova Soluciones </title>
</head>
<body>
	
	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->

	<div class="detalle_fondo_img">
		<img src="<?php echo e(asset('img/detalle_fondo.jpg')); ?>">
	</div>
	
	<div class="detalle contenedor-breadcrumb row m-auto ml-0 mr-0">
		<nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
		    <li class="breadcrumb-item"><a href="<?php echo e(route('productos')); ?>">Productos</a></li>
		    <li class="breadcrumb-item active" aria-current="page">Detalles</li>
		  </ol>
		</nav>
	</div>
	<section class="detalle detalle_referencia row m-auto ml-0 mr-0 flex-column-reverse flex-md-row">
		<?php $__currentLoopData = $producto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<section class="detalle_info col-12 col-md-4 pt-4 pt-md-4">
				<h1 class="detalle_info_titulo "><?php echo e($detalle->producto_nombre); ?></h1>
				<span class="detalle_info_tags">
					<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<a href="<?php echo e(route('productoTag', $tag)); ?>">
							<h3 class="tag"><?php echo e($tag); ?></h3>	
						</a>											
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</span>

				<!-- SECCION DE DESCUENTO O PROMOCION DEL PRODUCTO -->
				<?php if($detalle['promo_tipo']): ?>
					<span class="detalle_info_precio_anterior">
						<?php if($detalle['promo_tipo'] == '%'): ?>
							<p class="antes"> Antes COP$ <?php echo e(number_format($detalle['producto_precio'], 0, ',', '.')); ?></p>
							<span class="promo">
								<?php echo e($detalle['promo_costo']); ?>% DCTO
							</span>
						<?php elseif($detalle['promo_tipo'] == '$'): ?>
							<p class="antes"> Antes COP$ <?php echo e(number_format($detalle['producto_precio'], 0, ',', '.')); ?></p>
							<span class="promo">
								COP$ <?php echo e(number_format($detalle['promo_costo'], 0, ',', '.')); ?> <small>DCTO</small>
							</span>
						<?php elseif($detalle['promo_tipo'] == '2x1'): ?>
							<span class="promo"><?php echo e($detalle['promo_tipo']); ?></span>
						<?php endif; ?>					
					</span>
				<?php endif; ?>

				<!-- SECCION TOTAL DEL PRODUCTO -->
				<span class="detalle_info_precio detalle_info_item"> 
					<?php 
						if ($detalle['promo_tipo'] == '%') {
							$descuento = $detalle['producto_precio'] * ($detalle['promo_costo'] / 100);
							$total     = $detalle['producto_precio'] - $descuento;
							$total     = '<span class="ahora">Ahora</span>' . '<span class="total">COP$ ' .  number_format($total, 0, '', '.') . '</span>'; 
						}
						elseif($detalle['promo_tipo'] == '$'){
							$total = $detalle['producto_precio'] - $detalle['promo_costo'];
							$total = '<span class="ahora">Ahora</span>' . '<span class="total">COP$ ' .  number_format($total, 0, '', '.') . '</span>';
						}
						else {
							$total = '<span class="total">COP$ ' .   number_format($detalle['producto_precio'], 0, ',', '.') . '</span>';
						}
					 ?>
					<?php echo $total; ?>

				</span>
				<span class="detalle_info_costo_envio detalle_info_item">
					<i class="fa fa-truck detalle_info_icon" title="Envio gratis"></i>Envío gratis a todo Colombia
				</span>
				<span class="detalle_info_costo_envio detalle_info_item">
					<i class="fa fa-hourglass-half detalle_info_icon" title="Tiempo de entrega"></i>Tiempo de entrega: 20 días
				</span>				

				<!-- OPCIONAL SI ES ALGUN ARTICULO QUE REQUIERA DE TALLAS, COMO ZAPATOS, CAMISAS ETC -->
				<form class="detalle_info_form" id="datos-agregar-producto" action="<?php echo e(route('addItem')); ?>" method="post">
					<?php echo e(csrf_field()); ?>

					<input type="hidden" class="inputs" id="id" name="id" value="<?php echo e($detalle['id']); ?>">
					<input type="hidden" class="inputs" id="producto_ref" name="producto_ref" value="<?php echo e($detalle['producto_ref']); ?>">
					<?php if(empty(!$detalle['producto_colores'])): ?>
						<label for="colores">Colores</label>
						<select id="colores" name="colores" class="detalle_info_color" required>
							<?php $colores = explode( ',', $detalle['producto_colores'] ); ?>
							<?php $__currentLoopData = $colores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($color); ?>"><?php echo e($color); ?></option>					
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					<?php endif; ?>
					<?php if(empty(!$detalle['producto_tallas'])): ?>
						<label for="tallas">Tallas</label>
						<select id="tallas" name="tallas" class="detalle_info_talla" required>
							<?php $tallas = explode( ',', $detalle['producto_tallas'] ); ?>
							<?php $__currentLoopData = $tallas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $talla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($talla); ?>"><?php echo e($talla); ?></option>					
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					<?php endif; ?>
					<button type="submit" id="btn-agregar-producto" class="btn btn-primary detalle_info_btn_comprar">AÑADIR AL CARRITO</button>
				</form>
			</section>
			<div class="detalle_descripcion_container col-12 col-md-8 h-25">
				<!-- Va de primero la imagen que viene desde la tabla producto -->
				<div class="detalle_descripcion_container_img">
					<img class="img_principal" src='<?php echo e(asset("uploads/productos/imagenes/miniaturas/$detalle->producto_imagen")); ?>' alt="<?php echo e($detalle->producto_nombre); ?>">
					
				</div>
				<!-- <img class="img_principal" src='<?php echo e(asset("uploads/productos/imagenes/miniaturas/1563425529_asus1.png")); ?>' alt="imganes de descripcion"> -->
			</div> 
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</section>
	<section class="detalle detalle_referencia row m-auto ml-0 mr-0">
		<section class="col-12 col-md-4 pt-4 pt-md-4">
			<!-- <section class="detalle_info_descripcion">
				<article>
					<h2>Información de envío</h2>
				</article>
			</section> -->
		</section>
		<section class="col-12 col-md-8 p-3">
			<section class="detalle_info_descripcion p4">
				<article>
					<h2>Información del producto</h2>
					<p><?php echo $detalle->producto_descripcion; ?></p>
				</article>
			</section>
		</section>
			
	</section>

	<!-- SECCION FOOTER -->
	<?php echo $__env->make('includes/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN FOOTER -->
	
	<!-- SECCION SCRIPTS JS -->
	<?php echo $__env->make('includes/scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN SCRIPTS JS -->
</body>
</html>