	<?php $__env->startSection('title'); ?> 
		Productos de Innova
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('productos'); ?> active <?php $__env->stopSection(); ?>
	<?php $__env->startSection('contenido'); ?>
		<section class="col-12 col-md-10 contenido_principal">
			<header class="encabezado_principal">
				<h1 class="titulo_principal">Productos</h1>
				<div class="crear_productos">
					<a href="<?php echo e(route('showCreate')); ?>">
						<span class="fa fa-plus crear_productos_icon"></span>
						Crear producto
					</a>
				</div>
			</header>
			
			<!-- BUSCAR PRODUCTOS -->
			<section class="filtro">
				<form class="form-inline filtro_form" action="" method="POST">
					<input type="text" name="descripcion_producto" class="filtro_form_input filtro_descripcion" placeholder="Descripción">

					<select name="categoria_producto" class="filtro_form_input filtro_categoria">
						<option>Categoria</option>
						<?php if(isset($categorias)): ?>
							<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->categoria_nombre); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</select>

					<input type="text" name="referencia_producto" class="filtro_form_input filtro_referencia" placeholder="Referencia">

					<input type="number" min="1" name="precio_producto" class="filtro_form_input filtro_precio" placeholder="0.0">

					<input type="date" name="fecha_producto" class="filtro_form_input filtro_fecha">

					<button type="submit" class="filtro_btn_filtrar">Buscar</button>
				</form>
			</section>
			<!-- FIN BUSCAR PRODUCTOS -->
			<!-- TABLA DE PRODUCTOS -->
			<section class="contenedor_tabla">
				<section class="contenedor_tabla_head">
					<span class="contenedor_tabla_head_titulos producto-img">Img</span>
					<span class="contenedor_tabla_head_titulos producto-nombre">Nombre</span>
					<span class="contenedor_tabla_head_titulos producto-categoria d-none d-md-block">Categoría</span>
					<span class="contenedor_tabla_head_titulos producto-ref">Referencia</span>
					<span class="contenedor_tabla_head_titulos producto-precio">Precio</span>
					<span class="contenedor_tabla_head_titulos producto-promocion d-none d-md-block">Promoción</span>
					<span class="contenedor_tabla_head_titulos producto-talla-color d-none d-md-block">Tallas <br> colores</span>
					<span class="contenedor_tabla_head_titulos producto-operaciones">Operaciones</span>
				</section>
				<?php if(isset($productos)): ?>
					<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<section class="contenedor_tabla_body">
							<span class="contenedor_tabla_body_titulos producto-img">
								<img class="producto_img" src='<?php echo e(asset("uploads/productos/imagenes/miniaturas/$producto->producto_imagen")); ?>'>			
							</span>
							<span class="contenedor_tabla_body_titulos producto-nombre">
								<?php if(strlen($producto->producto_nombre) > 10): ?>
									<?php echo e(substr($producto->producto_nombre, 0, 60) . "..."); ?>

								<?php else: ?> 
									<?php echo e($producto->producto_nombre); ?>								
								<?php endif; ?>
							</span>
							<span class="contenedor_tabla_body_titulos producto-categoria d-none d-md-block">
								<?php echo e($producto->categoria_nombre); ?>

							</span>
							<span class="contenedor_tabla_body_titulos producto-ref"><?php echo e($producto->producto_ref); ?></span>
							<span class="contenedor_tabla_body_titulos producto-precio"><?php echo e(number_format($producto->producto_precio, 0, '', '.')); ?></span>
							<span class="contenedor_tabla_body_titulos producto-promocion d-none d-md-block">
								<?php if($producto->promo_tipo || $producto->promo_costo): ?>
									<?php echo e($producto->promo_tipo . ' - ' .$producto->promo_costo); ?>

								<?php else: ?>
									<?php echo e('_ _ _'); ?>

								<?php endif; ?>
							</span>
							<span class="contenedor_tabla_body_titulos producto-talla-color d-none d-md-block">
								<?php
									if($producto->producto_tallas || $producto->producto_colores) { 
										$data = $producto->producto_tallas . ", " . $producto->producto_colores;
										echo substr($data, 0, 25) . '...';
									}
									else {
										echo "_ _ _";
									}
								?>
							</span>
							<span class="contenedor_tabla_body_titulos producto-operaciones">
								<a data-toggle="tooltip" data-placement="top" title="Ver producto" href="<?php echo e(route ('getDetallesProducto', $producto->id )); ?>">
									<span class="fa fa-edit mr-2 btn-ver-item"></span>
								</a>  |  
								<a class="btnEliminarProducto" data-toggle="tooltip" data-placement="top" title="Eliminar producto" href="<?php echo e(route ('eliminarProducto', $producto->id )); ?>">
									<span class="fa fa-trash ml-2 btn-eliminar-item"></span>
								</a>
							</span>
						</section>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
				<?php endif; ?>
				<?php if($productos->links()): ?>
					<section class="paginacion_links">
						<?php echo e($productos->links()); ?>

					</section>
				<?php endif; ?>
			</section>
			<!-- FIN TABLA DE PRODUCTOS -->
		</section>
		<?php if(session('producto-creado')): ?>
			<script>
				alert('Producto creado correctamente');
			</script>
		<?php endif; ?>
		<?php if(session('mensaje')): ?>
			<script>
				alert( '<?php echo e(session('mensaje')); ?>' );
			</script>
		<?php endif; ?>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>