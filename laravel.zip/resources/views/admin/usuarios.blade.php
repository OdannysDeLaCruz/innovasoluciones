@extends('admin/layout')
	@section('title') 
		Usuarios del sistema
	@endsection
	@section('usuarios') active @endsection
	@section('contenido') 
		<section class="col-10 col-sm-10 col-md-10 contenido_principal">
			<header class="encabezado_principal">
				<h1 class="titulo_principal">Usuarios</h1>
			</header>
		</section>
	@endsection