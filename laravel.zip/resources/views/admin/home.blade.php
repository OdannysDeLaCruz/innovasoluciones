@extends('admin/layout')
	@section('title') 
		Administrador
	@endsection
	@section('inicio') active @endsection
	@section('contenido') 
		<section class="col-10 col-sm-10 col-md-10 contenido_principal">
			
		</section>
	@endsection