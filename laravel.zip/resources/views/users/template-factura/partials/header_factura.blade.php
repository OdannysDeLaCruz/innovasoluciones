<div class="header">
	<img class="logotipo" src="{{ asset('img/factura/LogoInnova.png') }}">
	<div style="width: 400px; float: right; text-align: right;">
		<p class="fecha_factura">Fecha de realizado de pedido: {{ $datos_factura['fecha_pedido'] }}</p><br>
		<p class="fecha_factura">Por favor, revisar ambas caras de la factura </p>
		
	</div>
</div>