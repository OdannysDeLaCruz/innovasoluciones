@isset($response)
	{{ $response }}
@else 
	{{ 'Ha ocurrido un error' }}
@endisset