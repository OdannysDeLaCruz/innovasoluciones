<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePedidosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pedidos', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id')->unsigned();
            $table->string('pedido_dir');
            $table->string('pedido_ref_venta')->nullable();
            $table->integer('promocion_id')->unsigned()->nullable();
            $table->integer('envio_id')->unsigned();
            $table->string('pedido_nombre_metodo_pago')->nullable(); // Obtener de Payu;
            $table->string('pedido_metodo_pago')->nullable(); // Forma de pago y metodo Ej: CREDIT_CARD - tal cosa
            $table->string('pedido_estado')->nullable();

            $table->integer('pedido_cuotas_pago')->nullable();
            $table->string('pedido_tipo_dispositivo')->nullable();
            $table->string('pedido_ip_dispositivo')->nullable();

            $table->string('pedido_transaccion_id')->nullable();
            $table->string('pedido_ref_venta_payu')->nullable();
            $table->string('pedido_moneda_pago')->nullable();
            
            $table->timestamp('fecha_transaccion_pago');
            $table->timestamp('fecha_creado');
            $table->timestamp('fecha_actualizado')->nullable();

            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('promocion_id')->references('id')->on('promociones')->onDelete('cascade');
            $table->foreign('envio_id')->references('id')->on('envios')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pedidos');
    }
}
