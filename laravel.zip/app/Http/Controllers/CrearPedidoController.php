<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App;
use Jenssegers\Agent\Agent;

class CrearPedidoController extends Controller
{
	public function crearPedido(Request $request) {

    	// Verificar si app.js envía una peticion ajax para crear el pedido
		if($request->ajax()) {
    		// Crear el pedido
			if ($_POST["crear"] == true) {
				date_default_timezone_set('America/Bogota');

				// Si hay productos en el carrito, crear pedido
				if($cart = session('cart')) {
					$pedido = App\Pedido::create([
				        'user_id'             => Auth::user()->id,
				        'pedido_dir'          => Auth::user()->usuario_direccion . ' ' . Auth::user()->usuario_barrio . ', ' . Auth::user()->usuario_ciudad . ', ' .  Auth::user()->usuario_pais,
				        'pedido_ref_venta'    => 'en espera',
				        'promocion_id'		  => session('promocion_id') ? session('promocion_id') : null,
				        'envio_id'            => session('tipo_envio'),
				        'pedido_nombre_metodo_pago' => 'en espera',
				        'pedido_metodo_pago'  => 'en espera',
				        'pedido_estado'       => 'en espera',

				        'pedido_cuotas_pago' => 1,

				        'pedido_tipo_dispositivo' => '',
				        'pedido_ip_dispositivo' => '',


				        'pedido_transaccion_id' => 'en espera',

				        'pedido_ref_venta_payu' => 'en espera',

				        'pedido_moneda_pago'  => 'en espera',

				        'fecha_transaccion_pago' => 'en espera'
			        ]);

			        if($pedido !== "") {
			        	$pedido_id = $pedido->id; 

	    				// Crear detalles del pedido
	    				$cart = session('cart');
	    				foreach ($cart as $detalle) {

	    					if (array_key_exists('promo_tipo', $detalle)) {
	    						$promo_info = "Tipo de promoción " . $detalle['promo_tipo'] . ", tiene un descuento de " . $detalle['promo_costo'];
	    					}else {
	    						$promo_info = '';
	    					}

				            App\DetallePedido::create([
						        'pedido_id'            => $pedido_id,
						        'detalle_producto_ref' => $detalle['producto_ref'],
						        'detalle_descripcion'  => $detalle['descripcion'],
						        'detalle_imagen'       => $detalle['imagen'],
						        'detalle_precio'       => $detalle['precio'],
						        'detalle_cantidad'     => $detalle['cantidad'],
						        'detalle_promo_info'   => $promo_info,
						        'detalle_precio_final' => $detalle['total'],
						        'detalle_talla'        => $detalle['talla'],
						        'detalle_color'        => $detalle['color']
		    				]);
				        }
				        
	    				// Eliminar todos los datos (variables) de session que esten relacionados con el pedido

	            		$datos_session = ['cart', 'codigos_usados', 'descuento_realizado', 'descuento_peso', 'total_pagar','total_del_pedido','tipo_envio', 'promocion_id'];
			            foreach ($datos_session as $session) {
			                if (session()->has($session)) {
			                    session()->forget($session);
			                }                
			            }
	    				
			        	// si se crea el pedido, los detalles y se elimina el carrito, entonces enviar confirmación al usuario

			        	echo json_encode(array(
							'status' => 'Success',
							'pedido_id' => $pedido_id,
							'message' => 'Pedido realizado correctamente, será llevado a Payu para realizar el pago'
						));

						// Enviar correo de confirmacion de la compra
			        }
			        else { 
			        	echo json_encode(array(
							'status' => 'Error',
							'id_pedido' => '',
							'message' => 'Error en la creacion del pedido'
						));
			        }
				}
				else {
					// carrito esta vacio
					echo json_encode(array(
						'status' => 'Error',
						'id_pedido' => '',
						'message' => 'No hay productos en el carrito'
					));
				}
				
			}
			else {
				echo json_encode(array(
					'status' => 'Error',
					'id_pedido' => '',
					'message' => 'Error al confirmar la creación del pedido'
				));
			}
        }
	}

	// Obtener tipo de dispositivo
	private function getDispositivo() {

		$agent = new Agent();

        // Sistema operativo
        $plataforma = $agent->platform();
        // Desktop
        $desktop  = $agent->isDesktop();
       	$mobile   = $agent->isMobile();
		$tablet   = $agent->isTablet();

		if($desktop){
			$dispositivo = 'Escritorio';
		}elseif ($mobile) {
			$dispositivo = 'Móvil';
		}else {
			$dispositivo = 'Tableta';
		}
        // Browser
        $browser = $agent->browser();
		$version = $agent->version($browser);

        $device = $agent->device();

        "Dispositivo " . $plataforma . "con "

        dd($plataforma, $desktop, $browser, $version, $device);
	}
	// Obtener ip del dispositivo
}
