<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pedido extends Model
{
    protected $table = "pedidos";
    protected $fillable = [
        'user_id',
        'pedido_dir',
        'pedido_ref_venta',
        'promocion_id',
        'envio_id',
        'pedido_nombre_metodo_pago',
        'pedido_metodo_pago',
        'pedido_estado',
        'pedido_transaccion_id',
        'pedido_moneda_pago',
        'fecha_transaccion_pago'
    ];

    public $timestamps = false;
}
