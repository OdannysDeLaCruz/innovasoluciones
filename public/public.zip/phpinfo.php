<?php 
	echo phpinfo();
 ?>