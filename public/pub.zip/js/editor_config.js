CKEDITOR.editorConfig = function( config ) {
	config.language = 'es';
};