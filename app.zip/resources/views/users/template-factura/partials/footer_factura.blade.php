<div class="footer">
	<img src="{{ asset('img/factura/footer-factura.png') }}">
</div>