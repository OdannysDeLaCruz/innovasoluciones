@extends('admin/layout')
	@section('title') 
		Códigos de descuentos
	@endsection
	@section('codigos') active @endsection
	@section('contenido') 
		<section class="col-10 col-sm-10 col-md-10 contenido_principal">
			<header class="encabezado_principal">
				<h1 class="titulo_principal">Códigos de descuentos</h1>
			</header>
		</section>
	@endsection