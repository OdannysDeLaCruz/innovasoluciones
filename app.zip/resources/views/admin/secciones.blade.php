@extends('admin/layout')
	@section('title') 
		Secciones de productos
	@endsection
	@section('secciones') active @endsection
	@section('contenido') 
		<section class="col-10 col-sm-10 col-md-10 contenido_principal">
			<header class="encabezado_principal">
				<h1 class="titulo_principal">Secciones</h1>
			</header>
		</section>
	@endsection