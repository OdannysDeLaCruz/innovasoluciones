<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/media-query.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<title> Compras realizadas | Usuario </title>
</head>
<body>

	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->
	
	<!-- SECCION PERFIL -->
	
		<?php $__env->startSection('pedidos'); ?> active <?php $__env->stopSection(); ?>
		<?php $__env->startSection('content'); ?>
			<section class="col-xs-12 col-md-10 pedidos_users">
				<h1 class="perfil_info_titulo mt-2 mb-4">Pedidos</h1>
				<?php if($mis_pedidos): ?>
					<?php $__currentLoopData = $mis_pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="pedidos">
							<header class="pedidos_cabecera">
								<span class="numero_pedidos">Ref. <?php echo e($pedido->pedido_ref_venta); ?></span>
								<span class="fecha_pedidos"><?php echo strftime('%A, %d de %B de %Y - %H:%M', strtotime($pedido->fecha_transaccion)); ?></span>		
							</header>
							<span class="pedidos_info">
								<div class="pedidos_info_datos">
									<!-- <span class="pedidos_info_datos_items pedidos_direccion">
										<span class="items_titulo"> Dirección de envío </span> 
										<?php echo e($pedido['pedido_dir']); ?>

									</span>
									<span class="pedidos_info_datos_items pedidos_referencia">
										<span class="items_titulo"> Referencia de venta </span>
										 <?php echo e($pedido['pedido_ref_venta']); ?>

									</span> -->
									<?php if($pedido['promo_nombre'] != null): ?>
										<span class="pedidos_info_datos_items pedidos_codigo_promocion">
											<span class="items_titulo"> Código de promoción </span>
											<span class="items-texto">												
													<?php echo e($pedido['promo_nombre']); ?>

											</span>
										</span>
									<?php endif; ?>
									<span class="pedidos_info_datos_items pedidos_estado">
										<span class="items_titulo"> Estado transacción</span>
										<?php if($pedido['estado'] == 0 || $pedido['estado'] == ''): ?>
											<p class="estados pedidos_estado_espera"> <?php echo e("En espera"); ?> </p>
										<?php elseif($pedido['estado'] == 4): ?>
											<p class="estados pedidos_estado_aprovada"> <?php echo e("Aprovada"); ?> </p>	
										<?php elseif($pedido['estado'] == 6): ?> 
											<p class="estados pedidos_estado_declinada"> <?php echo e("Declinada"); ?> </p>
										<?php elseif($pedido['estado'] == 5): ?>
											<p class="estados pedidos_estado_expirada"> <?php echo e("Expirada"); ?> </p>
										<?php endif; ?>
									</span>
									<span class="pedidos_info_datos_items pedidos_detalles"> 
										<a href="/perfil/pedidos/<?php echo e($pedido['id']); ?>"> Ver detalles</a>
									</span>	
								</div>
							</span>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					<p>Aún no realizado ningún pedido</p>
				<?php endif; ?>
			</section> 
		<?php $__env->stopSection(); ?>
	<!-- FIN PERFIL -->
</body>
</html>
<?php echo $__env->make('users/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>