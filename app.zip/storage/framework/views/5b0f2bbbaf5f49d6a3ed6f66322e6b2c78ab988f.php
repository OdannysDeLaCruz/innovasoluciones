<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<!-- CSS -->
	<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.11.2/build/css/alertify.min.css"/>
	<!-- Semantic UI theme -->
	<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.11.2/build/css/themes/semantic.min.css"/>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/media-query.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<title>Innova Soluciones | Cart </title>
</head>
<body>
	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->	
	<!-- SECCION CARRITO -->
	<section class="contenedor_carrito">
		<?php if(count($cart)): ?>
			<?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<section class="pedido carrito">
					<div class="pedido-img carrito-img">
						<a target="_blank" href="<?php echo e(route('descripcion', [ 'ref' => $carrito['producto_ref'], 'descripcion' => $carrito['nombre'] ])); ?>">
							<?php $url = "uploads/productos/imagenes/miniaturas/" . $carrito['imagen']; ?>
							<img src="<?php echo e($url); ?>">
						</a>
					</div>
					<div class="pedido-info">
						<ul class="pedido-info-list d-flex flex-column">
							<li class="pedido-info-list-item nombre-producto">
								<a target="_blank" href="<?php echo e(route('descripcion', [ 'ref' => $carrito['producto_ref'], 'descripcion' => $carrito['nombre'] ])); ?>">
									<?php echo e($carrito['nombre']); ?>

								</a>
							</li>
							<?php if($carrito['talla'] != ''): ?>
								<li class="pedido-info-list-item talla-producto">
									<b>Talla: <?php echo e($carrito['talla']); ?> </b>
								</li>
							<?php endif; ?>
							<?php if($carrito['color'] != ''): ?>
								<li class="pedido-info-list-item color-producto">
									<b>Color: <?php echo e($carrito['color']); ?> </b>
								</li>
							<?php endif; ?>
							<?php if($carrito['promocion'] != ''): ?>
								<li class="pedido-info-list-item promocion-producto">
									<span class="promocion-producto-precio-anterior">$<?php echo e(number_format($carrito['precio'], 0, '', '.')); ?></span>
									<span class="promocion-producto-tag"><?php echo e($carrito['promocion']); ?> OFF</span>
								</li>
							<?php endif; ?>
							<li class="pedido-info-list-item nombre-precio">
								$<?php echo e(number_format($carrito['total'], 0, '', '.')); ?> <small> COP</small>
							</li>
							<li class="pedido-info-list-item nombre-opciones">
								<div class="nombre-opciones-items nombre-opciones-cantidad">
									<input style="width: 30px;" class="ml-2" type="number" min="1" max="10" value="<?php echo e($carrito['cantidad']); ?>" id="producto_<?php echo e($carrito['id']); ?>">
									<a  data-toggle="tooltip"
						      			data-placement="top"
						      			title="Actualizar cantidad"
						      			href="#"
						      			class="btn_actualizar_carrito"
						      			data-href="<?php echo e(route('updateItem', $carrito['id'])); ?>"
						      			data-id="<?php echo e($carrito['id']); ?>"
						      		>
							      		<div class="fa fa-refresh"></div>
							      	</a>
								</div>
								<div class="nombre-opciones-items nombre-opciones-eliminar">
									<a href="<?php echo e(route('deleteItem', $carrito['id'])); ?>" data-toggle="tooltip" data-placement="top" title="Eliminar">
				      					<span class="fa fa-trash-o"></span>
				      				</a>
								</div>
							</li>
						</ul>
					</div>
				</section>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			<div class="suma_total_carrito">
				<small>Total a pagar:</small>
				$<?php echo e(number_format( session('total_del_pedido'), 0, ',', '.')); ?> <br>
				<?php if(session('codigos_usados')): ?>
					<small style="font-size: 13px;">Usted utilizó el código <?php echo e(session('codigos_usados')); ?></small>
					
				<?php endif; ?>
			</div>
			
			<span class="carrito_botones">
					
				<a href="<?php echo e(route('productos')); ?>" class="btn-innova btn-principal">
					<span class="fa fa-arrow-left mr-2"></span> Comprar más
				</a>

				<a href="<?php echo e(route('verificar')); ?>" class="btn-innova btn-principal">
					<span class="fa fa-credit-card-alt mr-2"></span> Tramitar
				</a>


			</span>
		<?php else: ?> 
			<!-- Elimino el las variables de session codigos_usados, descuento_peso y notificacion_codigo si no hay algo en el carrito-->
			<?php
				session()->forget('codigos_usados');				
				session()->forget('descuento_peso');				
				session()->forget('notificacion_codigo');		
			?>

			<div class="msm_carrito_vacio">
				<img class="msm_carrito_vacio_img" src="<?php echo e(asset('img/logos/shopping-bag.png')); ?>">
				<p class="msm_carrito_vacio_texto">Su carrito esta vacío</p>
			</div>
			<label class="carrito_botones ">		
				<a href="<?php echo e(route('productos')); ?>" class="btn-innova btn-principal">
					<span class="fa fa-arrow-left mr-2"> </span> Ir de compras
				</a>
			</label>
		<?php endif; ?>
	</section>
	<!-- FIN SECCION CARRITO -->
	<!-- SECCION FOOTER -->
	<?php echo $__env->make('includes/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<!-- FIN FOOTER -->	
	<!-- SECCION SCRIPTS JS -->
	<?php echo $__env->make('includes/scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN SCRIPTS JS -->

</body>
</html>