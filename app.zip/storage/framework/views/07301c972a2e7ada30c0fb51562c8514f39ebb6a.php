<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
	<link rel="stylesheet" type="text/css" href="css/media-query.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<title> Login | Innova Soluciones </title>
</head>
<body>

	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->
	
	<!-- SECCION DE FORMULARIO DE LOGIN -->
	<div class="contenedor_registro">
		<form class="form_registro" action="<?php echo e(route('login')); ?>" method="POST">
			<?php echo e(csrf_field()); ?> 
			<figure>
				<img class="form_registro_logo" src="img/logos/LogoInnova.svg">
			</figure>
			<h1 class="form_registro_titulo">Hola bienvenido, es un gusto tenerte aquí nuevamente.</h1>
			<div class="form_registro_grupo">

				<!-- USUARIO -->
				<label for="email" class="texto">E-mail</label>
				<input id="email" type="email" class="email <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Introduce tu Email" required>

				<?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
				
				<!-- CONTRASEÑA -->
				<label for="password" class="texto">Contraseña</label>
				<input id="password" type="password" class="password <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" value="<?php echo e(old('password')); ?>" placeholder="Digite su contraseña" required>

                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>

                <label class="recordar_password">
                    <input type="checkbox" name="remember" class="<?php echo e(old('remember') ? 'checked' : ''); ?>"> <?php echo e(__('Recordar clave')); ?>

				</label>

				<button type="submit" class="btn_registrarse">Ingresar</button>
				<div class="row">
					<label class="col-12 col-md-6 olvide_password text-md-left">
						<a href="<?php echo e(route('password.request')); ?>">Olvidé mi contraseña</a>
					</label>
					<label class="col-12 col-md-6 ya_tengo_cuenta text-md-right">
						<p>Aun no tengo una cuenta <a href="<?php echo e(route('register')); ?>">Registrarme</a></p>
					</label>
				</div>
			</div>
		</form>
	</div>
	<!-- FIN SECCION DE FORMULARIO DE LOGIN -->

	
	<!-- SECCION FOOTER -->
	<?php echo $__env->make('includes/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<!-- FIN FOOTER -->
	
	<!-- SECCION SCRIPTS JS -->
	<?php echo $__env->make('includes/scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN SCRIPTS JS -->
</body>
</html>