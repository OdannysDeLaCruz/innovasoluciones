<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/media-query.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<title> Compras realizadas | Usuario </title>
</head>
<body>

	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->
	
	<!-- SECCION PERFIL -->
	
		<?php $__env->startSection('pedidos'); ?> active <?php $__env->stopSection(); ?>
		<?php $__env->startSection('content'); ?>
			<?php if(!isset($Error)): ?>
				<section class="col-xs-12 col-md-10 compras_users">
					<h1 class="titulo_seccion mt-2 mb-4">
						<a class="btn btn-outline-dark btn-sm mr-2" style="text-decoration: none;" href="javascript:history.back(-1);" title="Ir la página anterior">
							<span class="fa fa-arrow-left mr-2"> </span>
								Pedido <?php echo e($pedido_ref); ?>

						</a>

						<span id="btn-toggle-detalles" class="compras_users_btn_toggle">
							<p class="compras_users_btn_toggle_texto" id="texto-toggle">Ocultar detalles</p>
							<span class="fa fa-chevron-down compras_users_btn_toggle_icon" id="icono-toggle"></span>
						</span>
					</h1>
					<span class="costo_pedido">
						Costo del pedido: $ <?php echo e($costo_pedido); ?>					
					</span>
					<?php if(isset($info_pedido) && isset($detalle_pedido)): ?>
						<?php $__currentLoopData = $info_pedido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<section class="row info_pedido row" id="info_pedido">
								<div class="info_pedido_seccion_block col-6 col-md-4 col-lg-">
									<span class="info_pedido_seccion_block_items titulo">Dirección envío</span>
									<span class="info_pedido_seccion_block_items texto">
										<?php echo e($direccion[0]->calle . ' #' . $direccion[0]->numero . ' ' . $direccion[0]->barrio); ?> <br>
										<?php echo e($direccion[0]->ciudad . ' - ' . $direccion[0]->departamento . ' - ' . $direccion[0]->pais); ?>

									</span>
								</div>
								<div class="info_pedido_seccion_block col-6 col-md-4 col-lg-">
									<span class="info_pedido_seccion_block_items titulo">Referencia de venta</span>
									<span class="info_pedido_seccion_block_items texto"><?php echo e($pedido->pedido_ref_venta); ?></span>
								</div>
								<!-- COSTO DE TRANSACCION PAGADO -->
								<div class="info_pedido_seccion_block col-6 col-md-4 col-lg-">
									<span class="info_pedido_seccion_block_items titulo">Valor de transacción pagado</span>
									<span class="info_pedido_seccion_block_items texto">
										<?php if($pedido->valor_transaccion != 0): ?>
											 <?php echo e("$ " . number_format($pedido->valor_transaccion, 0, '', '.') . ' ' . $pedido->tipo_moneda_transaccion); ?>										
										<?php else: ?>
											<?php echo e("$ 0"); ?>

										<?php endif; ?>
									</span>
								</div>
								<!-- PROMOCION -->
								<?php if($pedido->promo_nombre): ?> 
									<div class="info_pedido_seccion_block col-6 col-md-4 col-lg-">
										<span class="info_pedido_seccion_block_items titulo">Promoción</span>
										<span class="info_pedido_seccion_block_items texto">
												<?php echo e('Nombre: ' . $pedido->promo_nombre); ?> <br>
												<?php echo e('Costo: ' . $pedido->promo_tipo . ' ' . number_format($pedido->promo_costo, 0, '', '.')); ?> <br>
										</span>
									</div>
								<?php endif; ?>
								<!-- TIPO DE ENVIO -->
								<div class="info_pedido_seccion_block col-6 col-md-4 col-lg-">
									<span class="info_pedido_seccion_block_items titulo">Tipo de envío</span>
									<span class="info_pedido_seccion_block_items texto"><?php echo e($pedido->envio_metodo); ?></span>
								</div>
								<!-- ESTADO DEL PEDIDO -->
								<div class="info_pedido_seccion_block col-6 col-md-4 col-lg-">
									<span class="info_pedido_seccion_block_items titulo">Estado del pedido</span>
									<span class="info_pedido_seccion_block_items texto">
										<?php if($pedido->estado == 0 || $pedido->estado == ''): ?>
											<p class="estados pedidos_estado_espera"> <?php echo e("En espera"); ?> </p>	
										<?php elseif($pedido->estado == 4): ?> 
											<p class="estados pedidos_estado_aprovada"> <?php echo e("Aprovado"); ?> </p>
										<?php elseif($pedido->estado == 6): ?> 
											<p class="estados pedidos_estado_declinada"> <?php echo e("Declinada"); ?> </p>
										<?php elseif($pedido->estado == 5): ?>
											<p class="estados pedidos_estado_expirada"> <?php echo e("Expirada"); ?> </p>
										<?php endif; ?>										
									</span>
								</div>
								<!-- DESCRIPCION DE TRANSACCION -->
								<div class="info_pedido_seccion_block col-6 col-md-4 col-lg-">
									<span class="info_pedido_seccion_block_items titulo">Descripcion de transacción</span>
									<span class="info_pedido_seccion_block_items texto"><?php echo e($pedido->descripcion_transaccion); ?></span>
								</div>
								<!-- METODO DE PAGO -->
								<div class="info_pedido_seccion_block col-6 col-md-4 col-lg-">
									<span class="info_pedido_seccion_block_items titulo">Metodo de pago</span>
									<span class="info_pedido_seccion_block_items texto"><?php echo e($pedido->metodo_pago_nombre); ?></span>
								</div>
								<!-- NUMERO DE CUOTAS -->
								<div class="info_pedido_seccion_block col-6 col-md-4 col-lg-">
									<span class="info_pedido_seccion_block_items titulo">Número de cuotas</span>
									<span class="info_pedido_seccion_block_items texto"><?php echo e($pedido->numero_cuotas_pago); ?></span>
								</div>
								<!-- REFERENCIA DE VENTA DE PAYU -->
								<div class="info_pedido_seccion_block col-6 col-md-4 col-lg-">
									<span class="info_pedido_seccion_block_items titulo">Referencia venta de Payu</span>
									<span class="info_pedido_seccion_block_items texto"><?php echo e($pedido->referencia_venta_payu); ?></span>
								</div>
								<!-- TRANSACCIONES CON PSE -->
								<div class="info_pedido_seccion_block col-6 col-md-4 col-lg-">
									<span class="info_pedido_seccion_block_items titulo">Transacciones con PSE</span>
									<span class="info_pedido_seccion_block_items texto">
										<?php if($pedido->pse_bank): ?>
											<?php echo e("Banco: " . $pedido->pse_bank); ?> <br>
										<?php endif; ?>
										<?php if($pedido->pse_cus): ?>
											<?php echo e("Cus : " . $pedido->pse_cus); ?> <br>
										<?php endif; ?>
										<?php if($pedido->pse_references): ?>
											<?php echo e("Codigos: " . $pedido->pse_references); ?>

										<?php endif; ?>
									</span>
								</div>
								<!-- FECHA DE TRANSACCION -->
								<div class="info_pedido_seccion_block col-6 col-md-4 col-lg-">
									<span class="info_pedido_seccion_block_items titulo">Fecha de transacción</span>
									<span class="info_pedido_seccion_block_items texto">
										<?php echo strftime('%A, %d de %B de %Y - %H:%M', strtotime($pedido->fecha_transaccion)); ?>
									</span>
								</div>
							</section>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<?php $__currentLoopData = $detalle_pedido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="compras">
								<span class="compras_info">
									<a target="_blank" href="/productos/<?php echo e($detalle['detalle_producto_ref']); ?>-<?php echo e($detalle['detalle_nombre']); ?>">
										<img class="compras_info_img" src='<?php echo e(asset("uploads/productos/imagenes/miniaturas/$detalle->detalle_imagen")); ?>'></img>
									</a>
									<div class="compras_info_datos">
										<a target="_blanc" href="/productos/<?php echo e($detalle['detalle_producto_ref']); ?>-<?php echo e($detalle['detalle_nombre']); ?>">
											<span class="compras_info_descripcion"><?php echo e($detalle['detalle_nombre']); ?></span>
										</a>
										<span class="compras_info_datos_items compras_costo_cantidad">
											$ <?php echo e(number_format($detalle['detalle_precio'], 0, '', '.')); ?> x <?php echo e($detalle['detalle_cantidad']); ?> unidad(es)
										</span>
										<?php if($detalle['detalle_promo_info'] != ''): ?>
											<span class="compras_info_datos_items compras_promo_info">
												<?php echo e($detalle['detalle_promo_info']); ?>

											</span>
										<?php endif; ?>
										<span class="compras_info_datos_items compras_total">
											<?php 
												$precio = $detalle['precio'] * $detalle['cantidad'];
												$a_descontar = $precio * ($detalle['descuento_porcentual'] / 100);
												$total = $precio - $a_descontar;
											?> 
											Total: $ <?php echo e(number_format($detalle['detalle_precio_final'], 0, '', '.')); ?> 
										</span>	
									</div>
								</span>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</section>
			<?php else: ?> 
				<!-- si no existe compra, es por que la idPedido no existe para este usuario, verificamos si existe la variable Error -->
				<div class="compras_pedido">
					<span class="compras_pedido_error"><?php echo e($Error); ?></span>
				</div>			
			<?php endif; ?>
		<?php $__env->stopSection(); ?>
	<!-- FIN PERFIL -->
</body>
</html>
<?php echo $__env->make('users/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>