<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>" >

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/media-query.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<title>Innova Soluciones | Home </title>
</head>
<body>
	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->	

	<!-- SECCION CARRUSEL -->
	<?php echo $__env->make('includes/carrusel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<!-- FIN CARRUSEL -->

	<!-- SECCION CATEGORIAS -->
	<?php echo $__env->make('includes/secciones', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN CATEGORIAS -->

	<!-- SECCION NUEVOS PRODUCTOS -->
	<?php echo $__env->make('includes/nuevos_productos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<!-- FIN NUEVOS PRODUCTOS -->

	<!-- SECCION ALGUNOS PRODUCTOS -->
	<?php echo $__env->make('includes/algunos_productos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<!-- FIN ALGUNOS PRODUCTOS -->

	<!-- SECCION FOOTER -->
	<?php echo $__env->make('includes/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<!-- FIN FOOTER -->
	
	<!-- SECCION SCRIPTS JS -->
	<?php echo $__env->make('includes/scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN SCRIPTS JS -->
	
</body>
</html>