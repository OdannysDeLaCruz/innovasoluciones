<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<!-- CSS -->
	<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.11.2/build/css/alertify.min.css"/>
	<!-- Semantic UI theme -->
	<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.11.2/build/css/themes/semantic.min.css"/>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/estilos.css')); ?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/media-query.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<title> Checkout | Innova Soluciones</title>
</head>
<body>
	
	<!-- SECCION HEADER -->
	<?php echo $__env->make('includes/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN HEADER -->

	<!-- SECCION PRINCIPAL -->
	<section class="contenedor_payment row">
		<div class="col-md-8 seccion_metodo_pago">
			<h2 class="payment_titulos mt-3 mb-4">Casi terminas, pagar con:</h2>
			<div class="payment_opciones d-flex justify-content-arrow justify-md-content-center">
				<!-- Cargador de espera -->
				<div class="tarjeta_direccion_envio_cargador" id="cargador_formulario_payu">
					<img src="<?php echo e(asset('img/logos/cargador.gif')); ?>">
				</div>
				<div class="payment_opciones_items">
					<form method="post" id="enviar-formulario-payu" class="payment_opciones_items_form_payu" action="https://sandbox.checkout.payulatam.com/ppp-web-gateway-payu/">
						
					  	<input name="merchantId"    type="hidden"  value="<?php echo e($dataPayu['merchantId']); ?>">
					  	<input name="accountId"     type="hidden"  value="<?php echo e($dataPayu['accountId']); ?>" >
					  	<input name="description"   type="hidden"  value="<?php echo e($dataPayu['description']); ?>">
					  	<input name="extra2" id="pedido_id" type="hidden"  value="<?php echo e($dataPayu['extra2']); ?>">
					  	<input name="referenceCode" type="hidden"  value="<?php echo e($dataPayu['referenceCode']); ?>" >
					  	<input name="amount"        type="hidden"  value="<?php echo e($dataPayu['amount']); ?>"   >
					  	<input name="tax"           type="hidden"  value="<?php echo e($dataPayu['tax']); ?>"  >
					  	<input name="taxReturnBase" type="hidden"  value="<?php echo e($dataPayu['taxReturnBase']); ?>" >
					  	<input name="currency"      type="hidden"  value="<?php echo e($dataPayu['currency']); ?>" >
					  	<input name="signature"     type="hidden"  value="<?php echo e($dataPayu['signature']); ?>"  >
					  	<input name="test"          type="hidden"  value="<?php echo e($dataPayu['test']); ?>" >				  	
					  	<input name="buyerFullName" type="hidden"  value="<?php echo e($dataPayu['buyerFullName']); ?>" >
					  	<input name="buyerEmail"    type="hidden"  value="<?php echo e($dataPayu['buyerEmail']); ?>" >
					  	<input name="telephone"     type="hidden"  value="<?php echo e($dataPayu['telephone']); ?>" >			  	
					  	<input name="responseUrl"   type="hidden"  value="<?php echo e($dataPayu['responseUrl']); ?>" >
					  	<input name="confirmationUrl" type="hidden"  value="<?php echo e($dataPayu['confirmationUrl']); ?>" >
						
						<button type="submit" class="payment_opciones_items_form_btn_envio_dato px-3 py-1 px-md-5" id="crearPedidoPayu" data-route-crearpedido="<?php echo e(route('crear-pedido-payu')); ?>">
							<img src="<?php echo e(asset('img/logos/payu.png')); ?>">
						</button>
					</form>
				</div>
			</div>
			<a style="width: 200px;" class="btn btn-innova btn-principal" href="<?php echo e(route('verificar')); ?>">
				<span class="fa fa-arrow-left mr-2"></span> Volver a detalles
			</a>

			<h2 class="payment_subtitulos mt-5 mb-4">¿Qué medios de pagos te ofrecemos con PayU?</h2>

			<div class="payment_proceso_tarjeta seccion_metodo_pago_lista pt-4">
				<span class="seccion_metodo_pago_lista_items"> <img src="<?php echo e(asset('img/metodos_pago/visa.png')); ?>"> </span>
				<span class="seccion_metodo_pago_lista_items"> <img src="<?php echo e(asset('img/metodos_pago/davivienda.png')); ?>"> </span>
				<span class="seccion_metodo_pago_lista_items"> <img src="<?php echo e(asset('img/metodos_pago/mastercard.png')); ?>"> </span>
				<span class="seccion_metodo_pago_lista_items"> <img src="<?php echo e(asset('img/metodos_pago/american_express.png')); ?>"> </span>
				<span class="seccion_metodo_pago_lista_items"> <img src="<?php echo e(asset('img/metodos_pago/pse.png')); ?>"> </span>
				<span class="seccion_metodo_pago_lista_items"> <img src="<?php echo e(asset('img/metodos_pago/DinersClub_PayU.png')); ?>"> </span>
				<span class="seccion_metodo_pago_lista_items"> <img src="<?php echo e(asset('img/metodos_pago/bancobog-1.png')); ?>"> </span>
				<span class="seccion_metodo_pago_lista_items"> <img src="<?php echo e(asset('img/metodos_pago/codensa.png')); ?>"> </span>
				<span class="seccion_metodo_pago_lista_items"> <img src="<?php echo e(asset('img/metodos_pago/su_red.png')); ?>"> </span>
			</div>

			 
		</div>	
		<div class="col-md-4 seccion_resumen_pedido">
			<section class="payment_proceso_tarjeta tarjeta_resumen_pedidos">
				<span class="payment_proceso_tarjeta titulo_resumen_table">
					<strong>Resumen del pedido</strong>
				</span>
				<table class="table table-bordered resumen_table">
				  	<tr>
				    	<th>Productos (<?php echo e($cantidad_productos); ?>)</th>
				    	<td>$ <?php echo e(number_format( $total_del_pedido, 0, ',', '.')); ?> <small>COP</small></td>
				  	</tr>
				  	<?php if($descuento_peso > 0): ?>
				  	<tr>
				    	<th>Descuento por código</th>
				    	<td>$ <?php echo e(number_format( $descuento_peso, 0, ',', '.')); ?> <small>COP</small></td>
				  	</tr>
				  	<?php endif; ?>
				  	<tr>
				    	<th style="font-weight: 400;">TOTAL A PAGAR</th>
				    	<td>$ <?php echo e(number_format($total_pagar, 0, ',', '.')); ?> <small>COP</small></td>
				  	</tr>
				</table>
			</section>
		</div>
	</section>
	<!-- FIN PRINCIPAL -->

	<!-- SECCION FOOTER -->
	<?php echo $__env->make('includes/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<!-- FIN FOOTER -->
	
	<!-- SECCION SCRIPTS JS -->
	<?php echo $__env->make('includes/scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- FIN SCRIPTS JS -->

</body>
</html>