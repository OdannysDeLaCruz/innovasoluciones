<section class="contenedor_perfil">
	<section class="perfil row">
		<nav class="col-xs-12 col-md-2 perfil_menu">
			<div class="perfil_menu_avatar">
				<div class="perfil_menu_avatar_contenedor">
					<div class="perfil_menu_avatar_contenedor_img">
						<img src="<?php echo e(asset('uploads/avatars/avatar.png')); ?>">			
					</div>
				</div>							
				<label class="perfil_menu_avatar_nombre"> <?php echo e(Auth::user()->usuario_nombre); ?> <?php echo e(Auth::user()->usuario_apellido); ?> </label>
			</div>
			<ul class="perfil_menu_ul">
				<li><a class="<?php echo $__env->yieldContent('perfil'); ?>" href="<?php echo e(route('perfil')); ?>">Perfil</a></li>
				<li><a class="<?php echo $__env->yieldContent('pedidos'); ?>" href="<?php echo e(route('pedidos')); ?>">Pedidos</a></li>
				<li><a class="<?php echo $__env->yieldContent('facturas'); ?>" href="<?php echo e(route('facturas')); ?>">Facturas</a></li>
				<li class="btn-salir ">
					<a href="<?php echo e(route('logout')); ?>" 
						onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"> Cerrar sesión 
                    </a>
                </li>
				<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
			</ul>
		</nav>
		<?php echo $__env->yieldContent('content'); ?>
	</section>		
</section>

<!-- SECCION SCRIPTS JS -->
<?php echo $__env->make('includes/scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- FIN SCRIPTS JS -->