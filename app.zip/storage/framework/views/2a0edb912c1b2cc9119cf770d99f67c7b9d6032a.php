<!--SECCION NAV CATEGORIAS -->
<nav class="nav_categorias">
	<?php $__currentLoopData = $secciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php
			$ruta = str_replace(' ','-', $seccion['seccion_nombre']);
			$ruta = strtolower($ruta);
		?>
		<a href="/productos/<?php echo e($ruta); ?>"> <?php echo e($seccion['seccion_nombre']); ?> </a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>
<!-- FIN SECCION NAV CATEGORIAS