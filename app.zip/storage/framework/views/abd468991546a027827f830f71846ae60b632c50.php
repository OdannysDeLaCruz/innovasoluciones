<header class="header_principal">

    <span class="abrir_menu">
        <img fill="#fff" src="<?php echo e(asset('img/generals-icons/icono-abrir-menu.svg')); ?>">
    </span>

    <nav class="nav_principal" id="nav_principal">
        <ul>
            <div class="cerrar_menu">
                <img id="cerrar_menu" src="<?php echo e(asset('img/generals-icons/icono-cerrar-menu.svg')); ?>">
            </div>

            <!-- Authentication Links -->
            <?php if(auth()->guard()->guest()): ?>

                <span class="nav_principal_links_login">
                    <a href="<?php echo e(route('login')); ?>"> Ingresar</a> ó <a href="<?php echo e(route('register')); ?>">Registrarse</a>
                </span>
                <div class="nav_principal_separador"></div>

                <li><a href="<?php echo e(route('home')); ?>"><img class="logos_menu"></img> Home</a></li>
                <li><a href="<?php echo e(route('productos')); ?>"><img class="logos_menu"></img> Productos</a></li>

                <div class="nav_principal_separador"></div>

                <li><a href="">Centro de ayuda</a></li>
                <li><a href="">Contáctenos</a></li>

            <?php else: ?>
                <div class="information-user-logged">
                    <div class="information-user-logged-img">
                        <img src="<?php echo e(asset('uploads/avatars/avatar.png')); ?>">
                    </div>
                    <span class="information-user-logged-nombre">
                        <?php echo e(Auth::user()->usuario_nombre); ?> <?php echo e(Auth::user()->usuario_apellido); ?>

                    </span>
                    <?php if(Auth::user()->rol_id == 1): ?>
                        <span class="information-user-logged-item"> Administrador </span>
                    <?php endif; ?>
                </div>

                <div class="nav_principal_separador"></div>

                <li><a href="<?php echo e(route('perfil')); ?>">Mi Perfil</a></li>
                <?php if(Auth::user()->rol_id == 1): ?>
                    <li><a target="blank" href="<?php echo e(route('admin')); ?>">Panel de administración</a></li>
                <?php endif; ?>

                <div class="nav_principal_separador"></div>

                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li><a href="<?php echo e(route('productos')); ?>">Productos</a></li>

                <div class="nav_principal_separador"></div>

                <li><a href="">Centro de ayuda</a></li>
                <li><a href="">Contáctenos</a></li>

                <div class="nav_principal_separador"></div>

                <li class="btn_cerrar_sesion">
                    <a href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit(); ">
                        Cerrar sesión
                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
	<a class="header_principal_img d-none d-md-block" href="<?php echo e(route('home')); ?>">
		<img src="<?php echo e(asset('img/logos/logo-innova-blanco.svg')); ?>" alt="Logotipo de Innova Soluciones">
	</a>
	<div class="contenedor_formulario">
		<form class="formulario_buscar_producto" action="<?php echo e(route('searchtags')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <input class="input_buscador_producto" type="text" name="search" placeholder="Busca tu producto" value="<?php if(isset($search)): ?> <?php echo e($search); ?> <?php endif; ?>" required>
            <button class="btn_buscar" type="submit"><span class="fa fa-search"></span></button>
        </form>
	</div>

    <a class="link_cart" href="<?php echo e(route('showCart')); ?>">
        <?php 
            $cantidad_productos = 0;
            $cart = session('cart');
            
            if(!empty($cart)) {
                foreach ($cart as $producto) {
                    $cantidad_productos += $producto['cantidad'];
                }
            }     
        ?>
            
        <span id="carrito_icono" class="fa fa-cart-plus carrito_icono">
            <span class="notificacion_carrito"><?php echo e($cantidad_productos); ?></span>
        </span>
    </a>
	
</header>