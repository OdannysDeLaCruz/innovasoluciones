<section class="seccion_algunos_productos">
	<h1 class="seccion_algunos_productos_titulo">Estos son algunos de nuestros productos</h1>
	<div class="seccion_algunos_productos_content">

		<?php $__currentLoopData = $algunos_productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $algunos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php 
				$ref  = $algunos['producto_ref'];
				$nombre = str_replace(" ", "_", $algunos['producto_nombre']);
			?>
			<section class="producto">
				<figure>
					<a href="<?php echo e(route('descripcion', [ 'ref' => $ref, 'descripcion' => $nombre ])); ?>">
						<img src='<?php echo e(asset("uploads/productos/imagenes/miniaturas/$algunos->producto_imagen")); ?>' class="producto_img" alt="<?php echo e($algunos->producto_nombre); ?>">
					</a>
				</figure>
			</section>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>
	<div class="btn_seccion_ver_mas botones_innova">
		<a href="<?php echo e(route('productos')); ?>">Ver mas productos</a>
	</div>
</section>